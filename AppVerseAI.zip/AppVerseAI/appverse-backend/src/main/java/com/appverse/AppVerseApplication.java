package com.appverse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppVerseApplication {
    public static void main(String[] args) {
        SpringApplication.run(AppVerseApplication.class, args);
    }
}
