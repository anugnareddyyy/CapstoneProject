package com.appverse.controller;

import com.appverse.dto.response.ApiResponse;
import com.appverse.dto.response.AppResponse;
import com.appverse.service.AIRecommendationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
@Tag(name = "AI Features", description = "AI recommendations, sentiment analysis and analytics")
public class AIController {

    private final AIRecommendationService aiService;

    @GetMapping("/recommendations")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get personalized app recommendations for current user")
    public ResponseEntity<ApiResponse<List<AppResponse>>> getRecommendations(
            @AuthenticationPrincipal UserDetails userDetails) {
        List<AppResponse> recs = aiService.getPersonalizedRecommendations(userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Personalized recommendations", recs));
    }

    @GetMapping("/similar/{appId}")
    @Operation(summary = "Get similar apps based on category and ratings")
    public ResponseEntity<ApiResponse<List<AppResponse>>> getSimilarApps(@PathVariable Long appId) {
        return ResponseEntity.ok(ApiResponse.success("Similar apps", aiService.getSimilarApps(appId)));
    }

    @GetMapping("/trending")
    @Operation(summary = "Get trending apps by download count")
    public ResponseEntity<ApiResponse<List<AppResponse>>> getTrendingApps() {
        return ResponseEntity.ok(ApiResponse.success("Trending apps", aiService.getTrendingApps()));
    }

    @PostMapping("/analyze-sentiment")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Analyze sentiment of a given text")
    public ResponseEntity<ApiResponse<Map<String, Object>>> analyzeSentiment(
            @RequestBody Map<String, String> body) {
        String text = body.getOrDefault("text", "");
        if (text.isBlank()) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Text field is required"));
        }
        Map<String, Object> result = aiService.analyzeReviewSentiment(text);
        return ResponseEntity.ok(ApiResponse.success("Sentiment analysis complete", result));
    }

    @GetMapping("/analytics/{appId}")
    @PreAuthorize("hasAnyRole('DEVELOPER', 'ADMIN')")
    @Operation(summary = "Get download analytics and predictions for an app")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getDownloadAnalytics(
            @PathVariable Long appId) {
        Map<String, Object> analytics = aiService.getDownloadAnalytics(appId);
        return ResponseEntity.ok(ApiResponse.success("Analytics data", analytics));
    }
}
