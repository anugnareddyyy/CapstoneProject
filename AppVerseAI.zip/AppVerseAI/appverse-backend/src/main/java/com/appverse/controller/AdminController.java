package com.appverse.controller;

import com.appverse.dto.response.ApiResponse;
import com.appverse.dto.response.AppResponse;
import com.appverse.dto.response.UserResponse;
import com.appverse.entity.Role;
import com.appverse.entity.User;
import com.appverse.exception.ResourceNotFoundException;
import com.appverse.repository.UserRepository;
import com.appverse.service.AppService;
import com.appverse.service.ReviewService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
@Tag(name = "Admin Dashboard", description = "Admin-only platform management endpoints")
public class AdminController {

    private final UserRepository userRepository;
    private final AppService appService;
    private final ReviewService reviewService;

    @GetMapping("/users")
    @Operation(summary = "Get all registered users")
    public ResponseEntity<ApiResponse<List<UserResponse>>> getAllUsers() {
        List<UserResponse> users = userRepository.findAll().stream()
                .map(this::mapUserToResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(ApiResponse.success("All users fetched", users));
    }

    @GetMapping("/users/{id}")
    @Operation(summary = "Get user by ID")
    public ResponseEntity<ApiResponse<UserResponse>> getUserById(@PathVariable Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", id));
        return ResponseEntity.ok(ApiResponse.success("User fetched", mapUserToResponse(user)));
    }

    @PutMapping("/users/{id}/toggle-active")
    @Operation(summary = "Activate or deactivate a user account")
    public ResponseEntity<ApiResponse<UserResponse>> toggleUserActive(@PathVariable Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", id));
        user.setActive(!user.isActive());
        userRepository.save(user);
        String status = user.isActive() ? "activated" : "deactivated";
        return ResponseEntity.ok(ApiResponse.success("User " + status, mapUserToResponse(user)));
    }

    @PutMapping("/users/{id}/role")
    @Operation(summary = "Change a user's role")
    public ResponseEntity<ApiResponse<UserResponse>> changeUserRole(
            @PathVariable Long id,
            @RequestParam String role) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", id));
        user.setRole(Role.valueOf(role.toUpperCase()));
        userRepository.save(user);
        return ResponseEntity.ok(ApiResponse.success("Role updated", mapUserToResponse(user)));
    }

    @GetMapping("/apps")
    @Operation(summary = "Get all apps including unpublished")
    public ResponseEntity<ApiResponse<List<AppResponse>>> getAllApps() {
        // Admins can see all apps
        return ResponseEntity.ok(ApiResponse.success("All apps", appService.getAllPublishedApps()));
    }

    @GetMapping("/reviews/flagged")
    @Operation(summary = "Get all flagged reviews")
    public ResponseEntity<ApiResponse<?>> getFlaggedReviews() {
        return ResponseEntity.ok(ApiResponse.success("Flagged reviews", reviewService.getFlaggedReviews()));
    }

    @GetMapping("/stats")
    @Operation(summary = "Get platform overview statistics")
    public ResponseEntity<ApiResponse<?>> getPlatformStats() {
        long totalUsers = userRepository.count();
        long totalDevelopers = userRepository.findByRole(Role.DEVELOPER).size();
        long totalPublishedApps = appService.getAllPublishedApps().size();
        long flaggedReviews = reviewService.getFlaggedReviews().size();

        java.util.Map<String, Object> stats = new java.util.LinkedHashMap<>();
        stats.put("totalUsers", totalUsers);
        stats.put("totalDevelopers", totalDevelopers);
        stats.put("totalPublishedApps", totalPublishedApps);
        stats.put("flaggedReviews", flaggedReviews);

        return ResponseEntity.ok(ApiResponse.success("Platform stats", stats));
    }

    private UserResponse mapUserToResponse(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .fullName(user.getFullName())
                .role(user.getRole().name())
                .profilePicture(user.getProfilePicture())
                .active(user.isActive())
                .createdAt(user.getCreatedAt())
                .build();
    }
}
