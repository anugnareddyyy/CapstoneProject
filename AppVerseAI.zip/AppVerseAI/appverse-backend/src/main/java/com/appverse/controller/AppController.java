package com.appverse.controller;

import com.appverse.dto.request.AppRequest;
import com.appverse.dto.response.ApiResponse;
import com.appverse.dto.response.AppResponse;
import com.appverse.service.AppService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/apps")
@RequiredArgsConstructor
@Tag(name = "App Marketplace", description = "Browse, search, and manage apps")
public class AppController {

    private final AppService appService;

    @GetMapping
    @Operation(summary = "Get all published apps")
    public ResponseEntity<ApiResponse<List<AppResponse>>> getAllApps() {
        return ResponseEntity.ok(ApiResponse.success("Apps fetched", appService.getAllPublishedApps()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get app by ID")
    public ResponseEntity<ApiResponse<AppResponse>> getAppById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("App fetched", appService.getAppById(id)));
    }

    @GetMapping("/search")
    @Operation(summary = "Search apps by keyword")
    public ResponseEntity<ApiResponse<List<AppResponse>>> searchApps(@RequestParam String keyword) {
        return ResponseEntity.ok(ApiResponse.success("Search results", appService.searchApps(keyword)));
    }

    @GetMapping("/category/{categoryId}")
    @Operation(summary = "Get apps by category")
    public ResponseEntity<ApiResponse<List<AppResponse>>> getByCategory(@PathVariable Long categoryId) {
        return ResponseEntity.ok(ApiResponse.success("Apps by category", appService.getAppsByCategory(categoryId)));
    }

    @GetMapping("/featured")
    @Operation(summary = "Get featured apps")
    public ResponseEntity<ApiResponse<List<AppResponse>>> getFeaturedApps() {
        return ResponseEntity.ok(ApiResponse.success("Featured apps", appService.getFeaturedApps()));
    }

    @GetMapping("/trending")
    @Operation(summary = "Get trending apps")
    public ResponseEntity<ApiResponse<List<AppResponse>>> getTrendingApps() {
        return ResponseEntity.ok(ApiResponse.success("Trending apps", appService.getTrendingApps()));
    }

    @GetMapping("/{id}/similar")
    @Operation(summary = "Get similar apps")
    public ResponseEntity<ApiResponse<List<AppResponse>>> getSimilarApps(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Similar apps", appService.getSimilarApps(id)));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('DEVELOPER', 'ADMIN')")
    @Operation(summary = "Create a new app (Developer/Admin only)")
    public ResponseEntity<ApiResponse<AppResponse>> createApp(
            @Valid @RequestBody AppRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        AppResponse response = appService.createApp(request, userDetails.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("App created successfully", response));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('DEVELOPER', 'ADMIN')")
    @Operation(summary = "Update an app")
    public ResponseEntity<ApiResponse<AppResponse>> updateApp(
            @PathVariable Long id,
            @Valid @RequestBody AppRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        AppResponse response = appService.updateApp(id, request, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("App updated successfully", response));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('DEVELOPER', 'ADMIN')")
    @Operation(summary = "Delete an app")
    public ResponseEntity<ApiResponse<Void>> deleteApp(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        appService.deleteApp(id, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("App deleted successfully", null));
    }

    @PutMapping("/{id}/publish")
    @PreAuthorize("hasAnyRole('DEVELOPER', 'ADMIN')")
    @Operation(summary = "Publish an app")
    public ResponseEntity<ApiResponse<AppResponse>> publishApp(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        AppResponse response = appService.publishApp(id, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("App published successfully", response));
    }

    @PostMapping("/{id}/download")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Download an app")
    public ResponseEntity<ApiResponse<AppResponse>> downloadApp(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        AppResponse response = appService.downloadApp(id, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("App downloaded successfully", response));
    }

    @GetMapping("/my-apps")
    @PreAuthorize("hasAnyRole('DEVELOPER', 'ADMIN')")
    @Operation(summary = "Get developer's own apps")
    public ResponseEntity<ApiResponse<List<AppResponse>>> getMyApps(
            @AuthenticationPrincipal UserDetails userDetails) {
        List<AppResponse> apps = appService.getAppsByDeveloper(userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Your apps", apps));
    }
}
