package com.appverse.controller;

import com.appverse.dto.request.ReviewRequest;
import com.appverse.dto.response.ApiResponse;
import com.appverse.dto.response.ReviewResponse;
import com.appverse.service.ReviewService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
@Tag(name = "Reviews", description = "App reviews and sentiment analysis")
public class ReviewController {

    private final ReviewService reviewService;

    @GetMapping("/app/{appId}")
    @Operation(summary = "Get all reviews for an app")
    public ResponseEntity<ApiResponse<List<ReviewResponse>>> getReviewsByApp(@PathVariable Long appId) {
        return ResponseEntity.ok(ApiResponse.success("Reviews fetched", reviewService.getReviewsByApp(appId)));
    }

    @GetMapping("/my-reviews")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get current user's reviews")
    public ResponseEntity<ApiResponse<List<ReviewResponse>>> getMyReviews(
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(ApiResponse.success("Your reviews",
                reviewService.getReviewsByUser(userDetails.getUsername())));
    }

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Create a new review")
    public ResponseEntity<ApiResponse<ReviewResponse>> createReview(
            @Valid @RequestBody ReviewRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        ReviewResponse response = reviewService.createReview(request, userDetails.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Review submitted", response));
    }

    @PutMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Update a review")
    public ResponseEntity<ApiResponse<ReviewResponse>> updateReview(
            @PathVariable Long id,
            @Valid @RequestBody ReviewRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        ReviewResponse response = reviewService.updateReview(id, request, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Review updated", response));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Delete a review")
    public ResponseEntity<ApiResponse<Void>> deleteReview(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        reviewService.deleteReview(id, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Review deleted", null));
    }

    @GetMapping("/app/{appId}/sentiment")
    @Operation(summary = "Get sentiment analysis for an app's reviews")
    public ResponseEntity<ApiResponse<Map<String, Long>>> getSentimentAnalysis(@PathVariable Long appId) {
        Map<String, Long> sentiment = reviewService.getSentimentAnalysis(appId);
        return ResponseEntity.ok(ApiResponse.success("Sentiment analysis", sentiment));
    }

    @GetMapping("/flagged")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Get all flagged reviews (Admin only)")
    public ResponseEntity<ApiResponse<List<ReviewResponse>>> getFlaggedReviews() {
        return ResponseEntity.ok(ApiResponse.success("Flagged reviews", reviewService.getFlaggedReviews()));
    }

    @PutMapping("/{id}/flag")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Flag a review (Admin only)")
    public ResponseEntity<ApiResponse<ReviewResponse>> flagReview(
            @PathVariable Long id,
            @RequestParam String reason) {
        return ResponseEntity.ok(ApiResponse.success("Review flagged", reviewService.flagReview(id, reason)));
    }
}
