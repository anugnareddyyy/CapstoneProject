package com.appverse.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class AppRequest {

    @NotBlank(message = "App name is required")
    @Size(min = 2, max = 100, message = "App name must be 2-100 characters")
    private String name;

    @NotBlank(message = "Description is required")
    @Size(min = 10, message = "Description must be at least 10 characters")
    private String description;

    private String iconUrl;

    private String downloadUrl;

    @NotBlank(message = "Version is required")
    private String version;

    @DecimalMin(value = "0.0", message = "Price cannot be negative")
    private BigDecimal price;

    private String releaseNotes;

    @NotNull(message = "Category ID is required")
    private Long categoryId;
}
