package com.appverse.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppResponse {
    private Long id;
    private String name;
    private String description;
    private String iconUrl;
    private String downloadUrl;
    private String version;
    private BigDecimal price;
    private Double averageRating;
    private Long totalDownloads;
    private String releaseNotes;
    private boolean published;
    private boolean featured;
    private String developerName;
    private Long developerId;
    private String categoryName;
    private Long categoryId;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
