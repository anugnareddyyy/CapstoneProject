package com.appverse.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReviewResponse {
    private Long id;
    private String content;
    private Integer rating;
    private String sentiment;
    private Double sentimentScore;
    private boolean flagged;
    private String flagReason;
    private String username;
    private Long userId;
    private Long appId;
    private String appName;
    private LocalDateTime createdAt;
}
