package com.appverse.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "reviews")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    @Column(nullable = false)
    private Integer rating; // 1-5

    @Column(name = "sentiment")
    @Builder.Default
    private String sentiment = "NEUTRAL"; // POSITIVE, NEGATIVE, NEUTRAL

    @Column(name = "sentiment_score")
    @Builder.Default
    private Double sentimentScore = 0.0;

    @Column(name = "is_flagged")
    @Builder.Default
    private boolean flagged = false;

    @Column(name = "flag_reason")
    private String flagReason;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "app_id", nullable = false)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private App app;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
}
