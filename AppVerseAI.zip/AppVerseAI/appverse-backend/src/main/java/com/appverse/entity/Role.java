package com.appverse.entity;

public enum Role {
    USER,
    DEVELOPER,
    ADMIN
}
