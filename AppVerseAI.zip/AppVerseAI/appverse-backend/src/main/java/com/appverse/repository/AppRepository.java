package com.appverse.repository;

import com.appverse.entity.App;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AppRepository extends JpaRepository<App, Long> {

    List<App> findByPublishedTrue();

    List<App> findByDeveloperId(Long developerId);

    List<App> findByCategoryIdAndPublishedTrue(Long categoryId);

    List<App> findByFeaturedTrueAndPublishedTrue();

    @Query("SELECT a FROM App a WHERE a.published = true AND " +
           "(LOWER(a.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(a.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    List<App> searchByKeyword(@Param("keyword") String keyword);

    @Query("SELECT a FROM App a WHERE a.published = true ORDER BY a.totalDownloads DESC")
    List<App> findTopByDownloads();

    @Query("SELECT a FROM App a WHERE a.published = true ORDER BY a.averageRating DESC")
    List<App> findTopByRating();

    @Query("SELECT a FROM App a WHERE a.category.id = :categoryId AND a.published = true AND a.id != :appId ORDER BY a.averageRating DESC")
    List<App> findSimilarApps(@Param("categoryId") Long categoryId, @Param("appId") Long appId);

    @Query("SELECT SUM(a.totalDownloads) FROM App a WHERE a.developer.id = :developerId")
    Long getTotalDownloadsByDeveloper(@Param("developerId") Long developerId);
}
