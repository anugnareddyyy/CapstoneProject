package com.appverse.repository;

import com.appverse.entity.Download;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DownloadRepository extends JpaRepository<Download, Long> {

    List<Download> findByUserId(Long userId);

    List<Download> findByAppId(Long appId);

    boolean existsByUserIdAndAppId(Long userId, Long appId);

    long countByAppId(Long appId);

    @Query("SELECT d.app.category.name, COUNT(d) FROM Download d GROUP BY d.app.category.name ORDER BY COUNT(d) DESC")
    List<Object[]> getDownloadsByCategory();

    @Query("SELECT d.app.id, d.app.name, COUNT(d) as dlCount FROM Download d " +
           "WHERE d.app.developer.id = :developerId GROUP BY d.app.id, d.app.name ORDER BY dlCount DESC")
    List<Object[]> getDownloadsByDeveloperApps(@Param("developerId") Long developerId);
}
