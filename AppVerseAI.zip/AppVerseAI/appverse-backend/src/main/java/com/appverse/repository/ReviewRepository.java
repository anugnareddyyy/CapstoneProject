package com.appverse.repository;

import com.appverse.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findByAppId(Long appId);

    List<Review> findByUserId(Long userId);

    Optional<Review> findByUserIdAndAppId(Long userId, Long appId);

    boolean existsByUserIdAndAppId(Long userId, Long appId);

    List<Review> findByFlaggedTrue();

    @Query("SELECT AVG(r.rating) FROM Review r WHERE r.app.id = :appId")
    Double getAverageRatingByAppId(@Param("appId") Long appId);

    @Query("SELECT r FROM Review r WHERE r.app.id = :appId AND r.flagged = false ORDER BY r.createdAt DESC")
    List<Review> findApprovedReviewsByAppId(@Param("appId") Long appId);

    @Query("SELECT r.sentiment, COUNT(r) FROM Review r WHERE r.app.id = :appId GROUP BY r.sentiment")
    List<Object[]> getSentimentCountByAppId(@Param("appId") Long appId);

    long countByAppId(Long appId);
}
