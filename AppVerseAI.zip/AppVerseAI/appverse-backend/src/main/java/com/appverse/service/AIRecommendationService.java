package com.appverse.service;

import com.appverse.dto.response.AppResponse;

import java.util.List;
import java.util.Map;

public interface AIRecommendationService {
    List<AppResponse> getPersonalizedRecommendations(String username);
    List<AppResponse> getSimilarApps(Long appId);
    List<AppResponse> getTrendingApps();
    Map<String, Object> analyzeReviewSentiment(String reviewText);
    Map<String, Object> getDownloadAnalytics(Long appId);
}
