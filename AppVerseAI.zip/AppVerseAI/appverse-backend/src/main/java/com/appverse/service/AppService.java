package com.appverse.service;

import com.appverse.dto.request.AppRequest;
import com.appverse.dto.response.AppResponse;

import java.util.List;

public interface AppService {
    AppResponse createApp(AppRequest request, String developerUsername);
    AppResponse updateApp(Long id, AppRequest request, String developerUsername);
    void deleteApp(Long id, String developerUsername);
    AppResponse getAppById(Long id);
    List<AppResponse> getAllPublishedApps();
    List<AppResponse> getAppsByDeveloper(String developerUsername);
    List<AppResponse> getAppsByCategory(Long categoryId);
    List<AppResponse> getFeaturedApps();
    List<AppResponse> searchApps(String keyword);
    List<AppResponse> getTrendingApps();
    List<AppResponse> getSimilarApps(Long appId);
    AppResponse publishApp(Long id, String developerUsername);
    AppResponse downloadApp(Long id, String username);
}
