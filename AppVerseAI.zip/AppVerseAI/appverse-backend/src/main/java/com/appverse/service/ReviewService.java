package com.appverse.service;

import com.appverse.dto.request.ReviewRequest;
import com.appverse.dto.response.ReviewResponse;

import java.util.List;
import java.util.Map;

public interface ReviewService {
    ReviewResponse createReview(ReviewRequest request, String username);
    ReviewResponse updateReview(Long id, ReviewRequest request, String username);
    void deleteReview(Long id, String username);
    List<ReviewResponse> getReviewsByApp(Long appId);
    List<ReviewResponse> getReviewsByUser(String username);
    List<ReviewResponse> getFlaggedReviews();
    ReviewResponse flagReview(Long id, String reason);
    Map<String, Long> getSentimentAnalysis(Long appId);
}
