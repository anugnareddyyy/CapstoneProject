package com.appverse.service.impl;

import com.appverse.dto.response.AppResponse;
import com.appverse.entity.App;
import com.appverse.entity.Download;
import com.appverse.entity.User;
import com.appverse.exception.ResourceNotFoundException;
import com.appverse.repository.AppRepository;
import com.appverse.repository.DownloadRepository;
import com.appverse.repository.ReviewRepository;
import com.appverse.repository.UserRepository;
import com.appverse.service.AIRecommendationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AIRecommendationServiceImpl implements AIRecommendationService {

    private final AppRepository appRepository;
    private final UserRepository userRepository;
    private final DownloadRepository downloadRepository;
    private final ReviewRepository reviewRepository;

    @Override
    @Transactional(readOnly = true)
    public List<AppResponse> getPersonalizedRecommendations(String username) {
        log.info("Generating AI recommendations for user: {}", username);
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));

        // Get user's downloaded apps
        List<Download> userDownloads = downloadRepository.findByUserId(user.getId());
        Set<Long> downloadedAppIds = userDownloads.stream()
                .map(d -> d.getApp().getId())
                .collect(Collectors.toSet());

        // Find preferred categories from download history
        Map<Long, Long> categoryFrequency = userDownloads.stream()
                .collect(Collectors.groupingBy(
                        d -> d.getApp().getCategory().getId(),
                        Collectors.counting()
                ));

        List<AppResponse> recommendations = new ArrayList<>();

        if (!categoryFrequency.isEmpty()) {
            // Recommend top apps from user's most-used categories, not already downloaded
            Long topCategoryId = Collections.max(categoryFrequency.entrySet(),
                    Map.Entry.comparingByValue()).getKey();

            List<AppResponse> categoryRecs = appRepository
                    .findByCategoryIdAndPublishedTrue(topCategoryId)
                    .stream()
                    .filter(app -> !downloadedAppIds.contains(app.getId()))
                    .sorted(Comparator.comparingDouble(App::getAverageRating).reversed())
                    .limit(5)
                    .map(this::mapToResponse)
                    .collect(Collectors.toList());
            recommendations.addAll(categoryRecs);
        }

        // Fill remaining with top-rated apps not yet downloaded
        if (recommendations.size() < 10) {
            List<AppResponse> topRated = appRepository.findTopByRating().stream()
                    .filter(app -> !downloadedAppIds.contains(app.getId()))
                    .filter(app -> recommendations.stream()
                            .noneMatch(r -> r.getId().equals(app.getId())))
                    .limit(10 - recommendations.size())
                    .map(this::mapToResponse)
                    .collect(Collectors.toList());
            recommendations.addAll(topRated);
        }

        log.info("Generated {} recommendations for user {}", recommendations.size(), username);
        return recommendations;
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppResponse> getSimilarApps(Long appId) {
        App app = appRepository.findById(appId)
                .orElseThrow(() -> new ResourceNotFoundException("App", appId));
        return appRepository.findSimilarApps(app.getCategory().getId(), appId)
                .stream().limit(6).map(this::mapToResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppResponse> getTrendingApps() {
        return appRepository.findTopByDownloads()
                .stream().limit(10).map(this::mapToResponse).collect(Collectors.toList());
    }

    @Override
    public Map<String, Object> analyzeReviewSentiment(String reviewText) {
        // Keyword-based NLP sentiment analysis
        String lower = reviewText.toLowerCase();
        List<String> positiveWords = List.of("great", "excellent", "amazing", "awesome",
                "fantastic", "love", "perfect", "best", "wonderful", "good", "nice",
                "helpful", "useful", "fast", "easy", "recommend", "outstanding");
        List<String> negativeWords = List.of("bad", "terrible", "awful", "worst", "horrible",
                "hate", "useless", "broken", "bug", "crash", "slow", "poor",
                "disappointing", "waste", "frustrating", "annoying", "difficult");

        long posCount = positiveWords.stream().filter(lower::contains).count();
        long negCount = negativeWords.stream().filter(lower::contains).count();
        long total = posCount + negCount;

        double positiveScore = total > 0 ? (double) posCount / total : 0.5;
        double negativeScore = total > 0 ? (double) negCount / total : 0.5;
        String sentiment = posCount > negCount ? "POSITIVE" : (negCount > posCount ? "NEGATIVE" : "NEUTRAL");

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("sentiment", sentiment);
        result.put("positiveScore", Math.round(positiveScore * 100.0) / 100.0);
        result.put("negativeScore", Math.round(negativeScore * 100.0) / 100.0);
        result.put("positiveKeywordsFound", posCount);
        result.put("negativeKeywordsFound", negCount);
        result.put("analysis", buildAnalysisText(sentiment, posCount, negCount));
        return result;
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> getDownloadAnalytics(Long appId) {
        App app = appRepository.findById(appId)
                .orElseThrow(() -> new ResourceNotFoundException("App", appId));

        long totalDownloads = downloadRepository.countByAppId(appId);
        long totalReviews = reviewRepository.countByAppId(appId);
        Map<String, Long> sentimentBreakdown = getSentimentBreakdown(appId);

        Map<String, Object> analytics = new LinkedHashMap<>();
        analytics.put("appId", appId);
        analytics.put("appName", app.getName());
        analytics.put("totalDownloads", totalDownloads);
        analytics.put("averageRating", app.getAverageRating());
        analytics.put("totalReviews", totalReviews);
        analytics.put("sentimentBreakdown", sentimentBreakdown);
        analytics.put("downloadPrediction", predictFutureDownloads(totalDownloads));
        return analytics;
    }

    // ---- Private helpers ----

    private Map<String, Long> getSentimentBreakdown(Long appId) {
        List<Object[]> results = reviewRepository.getSentimentCountByAppId(appId);
        Map<String, Long> map = new HashMap<>();
        map.put("POSITIVE", 0L);
        map.put("NEGATIVE", 0L);
        map.put("NEUTRAL", 0L);
        for (Object[] row : results) {
            map.put((String) row[0], (Long) row[1]);
        }
        return map;
    }

    private long predictFutureDownloads(long currentDownloads) {
        // Simple linear prediction: grow by 20% next month
        return Math.round(currentDownloads * 1.2);
    }

    private String buildAnalysisText(String sentiment, long pos, long neg) {
        if ("POSITIVE".equals(sentiment)) {
            return "Review shows positive sentiment with " + pos + " positive indicators.";
        } else if ("NEGATIVE".equals(sentiment)) {
            return "Review shows negative sentiment with " + neg + " negative indicators.";
        }
        return "Review sentiment is neutral or mixed.";
    }

    private AppResponse mapToResponse(App app) {
        return AppResponse.builder()
                .id(app.getId())
                .name(app.getName())
                .description(app.getDescription())
                .iconUrl(app.getIconUrl())
                .version(app.getVersion())
                .price(app.getPrice())
                .averageRating(app.getAverageRating())
                .totalDownloads(app.getTotalDownloads())
                .published(app.isPublished())
                .featured(app.isFeatured())
                .developerName(app.getDeveloper().getUsername())
                .developerId(app.getDeveloper().getId())
                .categoryName(app.getCategory().getName())
                .categoryId(app.getCategory().getId())
                .createdAt(app.getCreatedAt())
                .updatedAt(app.getUpdatedAt())
                .build();
    }
}
