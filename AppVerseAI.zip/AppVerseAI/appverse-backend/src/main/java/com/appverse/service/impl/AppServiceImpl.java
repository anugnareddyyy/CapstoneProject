package com.appverse.service.impl;

import com.appverse.dto.request.AppRequest;
import com.appverse.dto.response.AppResponse;
import com.appverse.entity.App;
import com.appverse.entity.Category;
import com.appverse.entity.Download;
import com.appverse.entity.User;
import com.appverse.exception.ResourceNotFoundException;
import com.appverse.exception.UnauthorizedException;
import com.appverse.repository.AppRepository;
import com.appverse.repository.CategoryRepository;
import com.appverse.repository.DownloadRepository;
import com.appverse.repository.UserRepository;
import com.appverse.service.AppService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AppServiceImpl implements AppService {

    private final AppRepository appRepository;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final DownloadRepository downloadRepository;

    @Override
    @Transactional
    public AppResponse createApp(AppRequest request, String developerUsername) {
        log.info("Developer {} creating app: {}", developerUsername, request.getName());

        User developer = getUserByUsername(developerUsername);
        Category category = getCategoryById(request.getCategoryId());

        App app = App.builder()
                .name(request.getName())
                .description(request.getDescription())
                .iconUrl(request.getIconUrl())
                .downloadUrl(request.getDownloadUrl())
                .version(request.getVersion() != null ? request.getVersion() : "1.0.0")
                .price(request.getPrice())
                .releaseNotes(request.getReleaseNotes())
                .developer(developer)
                .category(category)
                .build();

        app = appRepository.save(app);
        log.info("App created with id: {}", app.getId());
        return mapToResponse(app);
    }

    @Override
    @Transactional
    public AppResponse updateApp(Long id, AppRequest request, String developerUsername) {
        App app = getAppById_entity(id);
        validateDeveloperOwnership(app, developerUsername);

        Category category = getCategoryById(request.getCategoryId());

        app.setName(request.getName());
        app.setDescription(request.getDescription());
        app.setIconUrl(request.getIconUrl());
        app.setDownloadUrl(request.getDownloadUrl());
        app.setVersion(request.getVersion());
        app.setPrice(request.getPrice());
        app.setReleaseNotes(request.getReleaseNotes());
        app.setCategory(category);

        app = appRepository.save(app);
        log.info("App {} updated by developer {}", id, developerUsername);
        return mapToResponse(app);
    }

    @Override
    @Transactional
    public void deleteApp(Long id, String developerUsername) {
        App app = getAppById_entity(id);
        validateDeveloperOwnership(app, developerUsername);
        appRepository.delete(app);
        log.info("App {} deleted by developer {}", id, developerUsername);
    }

    @Override
    @Transactional(readOnly = true)
    public AppResponse getAppById(Long id) {
        return mapToResponse(getAppById_entity(id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppResponse> getAllPublishedApps() {
        return appRepository.findByPublishedTrue().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppResponse> getAppsByDeveloper(String developerUsername) {
        User developer = getUserByUsername(developerUsername);
        return appRepository.findByDeveloperId(developer.getId()).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppResponse> getAppsByCategory(Long categoryId) {
        return appRepository.findByCategoryIdAndPublishedTrue(categoryId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppResponse> getFeaturedApps() {
        return appRepository.findByFeaturedTrueAndPublishedTrue().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppResponse> searchApps(String keyword) {
        return appRepository.searchByKeyword(keyword).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppResponse> getTrendingApps() {
        return appRepository.findTopByDownloads().stream()
                .limit(10)
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AppResponse> getSimilarApps(Long appId) {
        App app = getAppById_entity(appId);
        return appRepository.findSimilarApps(app.getCategory().getId(), appId).stream()
                .limit(5)
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public AppResponse publishApp(Long id, String developerUsername) {
        App app = getAppById_entity(id);
        validateDeveloperOwnership(app, developerUsername);
        app.setPublished(true);
        app = appRepository.save(app);
        log.info("App {} published by developer {}", id, developerUsername);
        return mapToResponse(app);
    }

    @Override
    @Transactional
    public AppResponse downloadApp(Long id, String username) {
        App app = getAppById_entity(id);
        User user = getUserByUsername(username);

        Download download = Download.builder()
                .app(app)
                .user(user)
                .appVersion(app.getVersion())
                .build();
        downloadRepository.save(download);

        app.setTotalDownloads(app.getTotalDownloads() + 1);
        app = appRepository.save(app);
        log.info("App {} downloaded by user {}", id, username);
        return mapToResponse(app);
    }

    // ---- Private helpers ----

    private App getAppById_entity(Long id) {
        return appRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("App", id));
    }

    private User getUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));
    }

    private Category getCategoryById(Long categoryId) {
        return categoryRepository.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category", categoryId));
    }

    private void validateDeveloperOwnership(App app, String developerUsername) {
        if (!app.getDeveloper().getUsername().equals(developerUsername)) {
            throw new UnauthorizedException("You are not the owner of this app");
        }
    }

    private AppResponse mapToResponse(App app) {
        return AppResponse.builder()
                .id(app.getId())
                .name(app.getName())
                .description(app.getDescription())
                .iconUrl(app.getIconUrl())
                .downloadUrl(app.getDownloadUrl())
                .version(app.getVersion())
                .price(app.getPrice())
                .averageRating(app.getAverageRating())
                .totalDownloads(app.getTotalDownloads())
                .releaseNotes(app.getReleaseNotes())
                .published(app.isPublished())
                .featured(app.isFeatured())
                .developerName(app.getDeveloper().getUsername())
                .developerId(app.getDeveloper().getId())
                .categoryName(app.getCategory().getName())
                .categoryId(app.getCategory().getId())
                .createdAt(app.getCreatedAt())
                .updatedAt(app.getUpdatedAt())
                .build();
    }
}
