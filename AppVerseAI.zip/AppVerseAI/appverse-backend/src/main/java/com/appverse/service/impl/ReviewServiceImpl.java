package com.appverse.service.impl;

import com.appverse.dto.request.ReviewRequest;
import com.appverse.dto.response.ReviewResponse;
import com.appverse.entity.App;
import com.appverse.entity.Review;
import com.appverse.entity.User;
import com.appverse.exception.DuplicateResourceException;
import com.appverse.exception.ResourceNotFoundException;
import com.appverse.exception.UnauthorizedException;
import com.appverse.repository.AppRepository;
import com.appverse.repository.ReviewRepository;
import com.appverse.repository.UserRepository;
import com.appverse.service.ReviewService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final AppRepository appRepository;

    // Positive sentiment keywords
    private static final List<String> POSITIVE_KEYWORDS = List.of(
            "great", "excellent", "amazing", "awesome", "fantastic", "love", "perfect",
            "best", "wonderful", "brilliant", "superb", "outstanding", "incredible",
            "good", "nice", "helpful", "useful", "fast", "easy", "recommend"
    );

    // Negative sentiment keywords
    private static final List<String> NEGATIVE_KEYWORDS = List.of(
            "bad", "terrible", "awful", "worst", "horrible", "hate", "useless",
            "broken", "bug", "crash", "slow", "poor", "disappointing", "waste",
            "frustrating", "annoying", "difficult", "hard", "problem", "issue"
    );

    // Fake review indicators
    private static final List<String> FAKE_INDICATORS = List.of(
            "paid", "sponsored", "fake", "bot", "generated", "copy paste"
    );

    @Override
    @Transactional
    public ReviewResponse createReview(ReviewRequest request, String username) {
        User user = getUserByUsername(username);
        App app = getAppById(request.getAppId());

        if (reviewRepository.existsByUserIdAndAppId(user.getId(), app.getId())) {
            throw new DuplicateResourceException("You have already reviewed this app");
        }

        SentimentResult sentiment = analyzeSentiment(request.getContent(), request.getRating());
        boolean isFake = detectFakeReview(request.getContent());

        Review review = Review.builder()
                .content(request.getContent())
                .rating(request.getRating())
                .sentiment(sentiment.label())
                .sentimentScore(sentiment.score())
                .flagged(isFake)
                .flagReason(isFake ? "Possible fake review detected" : null)
                .user(user)
                .app(app)
                .build();

        review = reviewRepository.save(review);
        updateAppRating(app);
        log.info("Review created for app {} by user {}", app.getId(), username);

        return mapToResponse(review);
    }

    @Override
    @Transactional
    public ReviewResponse updateReview(Long id, ReviewRequest request, String username) {
        Review review = getReviewById(id);
        validateOwnership(review, username);

        SentimentResult sentiment = analyzeSentiment(request.getContent(), request.getRating());
        review.setContent(request.getContent());
        review.setRating(request.getRating());
        review.setSentiment(sentiment.label());
        review.setSentimentScore(sentiment.score());

        review = reviewRepository.save(review);
        updateAppRating(review.getApp());
        return mapToResponse(review);
    }

    @Override
    @Transactional
    public void deleteReview(Long id, String username) {
        Review review = getReviewById(id);
        validateOwnership(review, username);
        App app = review.getApp();
        reviewRepository.delete(review);
        updateAppRating(app);
        log.info("Review {} deleted by {}", id, username);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReviewResponse> getReviewsByApp(Long appId) {
        return reviewRepository.findApprovedReviewsByAppId(appId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReviewResponse> getReviewsByUser(String username) {
        User user = getUserByUsername(username);
        return reviewRepository.findByUserId(user.getId()).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReviewResponse> getFlaggedReviews() {
        return reviewRepository.findByFlaggedTrue().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public ReviewResponse flagReview(Long id, String reason) {
        Review review = getReviewById(id);
        review.setFlagged(true);
        review.setFlagReason(reason);
        review = reviewRepository.save(review);
        log.info("Review {} flagged: {}", id, reason);
        return mapToResponse(review);
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Long> getSentimentAnalysis(Long appId) {
        List<Object[]> results = reviewRepository.getSentimentCountByAppId(appId);
        Map<String, Long> sentimentMap = new HashMap<>();
        sentimentMap.put("POSITIVE", 0L);
        sentimentMap.put("NEGATIVE", 0L);
        sentimentMap.put("NEUTRAL", 0L);
        for (Object[] row : results) {
            sentimentMap.put((String) row[0], (Long) row[1]);
        }
        return sentimentMap;
    }

    // ---- Sentiment Analysis Logic ----

    private SentimentResult analyzeSentiment(String content, int rating) {
        String lower = content.toLowerCase();
        long positiveCount = POSITIVE_KEYWORDS.stream().filter(lower::contains).count();
        long negativeCount = NEGATIVE_KEYWORDS.stream().filter(lower::contains).count();

        double textScore = (positiveCount - negativeCount) / (double) Math.max(1, positiveCount + negativeCount);
        double ratingScore = (rating - 3.0) / 2.0; // -1 to +1
        double finalScore = (textScore * 0.6) + (ratingScore * 0.4);

        String label;
        if (finalScore > 0.1) label = "POSITIVE";
        else if (finalScore < -0.1) label = "NEGATIVE";
        else label = "NEUTRAL";

        return new SentimentResult(label, Math.round(finalScore * 100.0) / 100.0);
    }

    private boolean detectFakeReview(String content) {
        String lower = content.toLowerCase();
        return FAKE_INDICATORS.stream().anyMatch(lower::contains)
                || content.length() < 10
                || content.chars().distinct().count() < 5;
    }

    private void updateAppRating(App app) {
        Double avg = reviewRepository.getAverageRatingByAppId(app.getId());
        app.setAverageRating(avg != null ? Math.round(avg * 10.0) / 10.0 : 0.0);
        appRepository.save(app);
    }

    // ---- Private helpers ----

    private Review getReviewById(Long id) {
        return reviewRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Review", id));
    }

    private User getUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));
    }

    private App getAppById(Long id) {
        return appRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("App", id));
    }

    private void validateOwnership(Review review, String username) {
        if (!review.getUser().getUsername().equals(username)) {
            throw new UnauthorizedException("You are not the author of this review");
        }
    }

    private ReviewResponse mapToResponse(Review review) {
        return ReviewResponse.builder()
                .id(review.getId())
                .content(review.getContent())
                .rating(review.getRating())
                .sentiment(review.getSentiment())
                .sentimentScore(review.getSentimentScore())
                .flagged(review.isFlagged())
                .flagReason(review.getFlagReason())
                .username(review.getUser().getUsername())
                .userId(review.getUser().getId())
                .appId(review.getApp().getId())
                .appName(review.getApp().getName())
                .createdAt(review.getCreatedAt())
                .build();
    }

    private record SentimentResult(String label, double score) {}
}
