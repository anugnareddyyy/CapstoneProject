package com.appverse.controller;

import com.appverse.dto.request.AppRequest;
import com.appverse.dto.response.AppResponse;
import com.appverse.dto.response.ApiResponse;
import com.appverse.service.AppService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AppController.class)
@DisplayName("AppController Integration Tests")
class AppControllerTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;

    @MockBean private AppService appService;
    @MockBean private com.appverse.security.CustomUserDetailsService customUserDetailsService;
    @MockBean private com.appverse.security.JwtUtil jwtUtil;
    @MockBean private com.appverse.security.JwtAuthenticationFilter jwtAuthenticationFilter;

    private AppResponse sampleApp;
    private AppRequest appRequest;

    @BeforeEach
    void setUp() {
        sampleApp = AppResponse.builder()
                .id(1L).name("Test App")
                .description("Test description")
                .version("1.0.0").price(BigDecimal.ZERO)
                .averageRating(4.5).totalDownloads(100L)
                .published(true).featured(false)
                .developerName("devuser").developerId(1L)
                .categoryName("Productivity").categoryId(1L)
                .build();

        appRequest = new AppRequest();
        appRequest.setName("Test App");
        appRequest.setDescription("Test description long enough");
        appRequest.setVersion("1.0.0");
        appRequest.setPrice(BigDecimal.ZERO);
        appRequest.setCategoryId(1L);
    }

    @Test
    @DisplayName("GET /api/apps - returns published apps list")
    void getAllApps_returnsPublishedApps() throws Exception {
        when(appService.getAllPublishedApps()).thenReturn(List.of(sampleApp));

        mockMvc.perform(get("/api/apps"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data[0].name").value("Test App"));
    }

    @Test
    @DisplayName("GET /api/apps/{id} - returns app by id")
    void getAppById_returnsApp() throws Exception {
        when(appService.getAppById(1L)).thenReturn(sampleApp);

        mockMvc.perform(get("/api/apps/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.id").value(1))
                .andExpect(jsonPath("$.data.name").value("Test App"));
    }

    @Test
    @DisplayName("GET /api/apps/search - returns search results")
    void searchApps_returnsResults() throws Exception {
        when(appService.searchApps("test")).thenReturn(List.of(sampleApp));

        mockMvc.perform(get("/api/apps/search").param("keyword", "test"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data[0].name").value("Test App"));
    }

    @Test
    @DisplayName("GET /api/apps/featured - returns featured apps")
    void getFeaturedApps_returnsList() throws Exception {
        when(appService.getFeaturedApps()).thenReturn(List.of(sampleApp));

        mockMvc.perform(get("/api/apps/featured"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    @DisplayName("POST /api/apps - 201 when developer creates app")
    @WithMockUser(username = "devuser", roles = {"DEVELOPER"})
    void createApp_returns201_whenDeveloper() throws Exception {
        when(appService.createApp(any(AppRequest.class), eq("devuser"))).thenReturn(sampleApp);

        mockMvc.perform(post("/api/apps")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(appRequest)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.name").value("Test App"));
    }

    @Test
    @DisplayName("POST /api/apps - 403 when USER role creates app")
    @WithMockUser(username = "normaluser", roles = {"USER"})
    void createApp_returns403_whenUser() throws Exception {
        mockMvc.perform(post("/api/apps")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(appRequest)))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("PUT /api/apps/{id}/publish - publishes app")
    @WithMockUser(username = "devuser", roles = {"DEVELOPER"})
    void publishApp_returnsPublishedApp() throws Exception {
        sampleApp = AppResponse.builder()
                .id(1L).name("Test App").published(true)
                .developerName("devuser").developerId(1L)
                .categoryName("Productivity").categoryId(1L)
                .price(BigDecimal.ZERO).version("1.0.0")
                .averageRating(0.0).totalDownloads(0L)
                .build();
        when(appService.publishApp(eq(1L), eq("devuser"))).thenReturn(sampleApp);

        mockMvc.perform(put("/api/apps/1/publish").with(csrf()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.published").value(true));
    }

    @Test
    @DisplayName("DELETE /api/apps/{id} - deletes app as owner")
    @WithMockUser(username = "devuser", roles = {"DEVELOPER"})
    void deleteApp_returns200() throws Exception {
        mockMvc.perform(delete("/api/apps/1").with(csrf()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }
}
