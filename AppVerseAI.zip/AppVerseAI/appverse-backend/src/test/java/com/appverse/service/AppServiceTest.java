package com.appverse.service;

import com.appverse.dto.request.AppRequest;
import com.appverse.dto.response.AppResponse;
import com.appverse.entity.*;
import com.appverse.exception.ResourceNotFoundException;
import com.appverse.exception.UnauthorizedException;
import com.appverse.repository.AppRepository;
import com.appverse.repository.CategoryRepository;
import com.appverse.repository.DownloadRepository;
import com.appverse.repository.UserRepository;
import com.appverse.service.impl.AppServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("AppService Unit Tests")
class AppServiceTest {

    @Mock private AppRepository appRepository;
    @Mock private UserRepository userRepository;
    @Mock private CategoryRepository categoryRepository;
    @Mock private DownloadRepository downloadRepository;

    @InjectMocks
    private AppServiceImpl appService;

    private User developer;
    private Category category;
    private App app;
    private AppRequest appRequest;

    @BeforeEach
    void setUp() {
        developer = User.builder()
                .id(1L)
                .username("devuser")
                .email("dev@email.com")
                .role(Role.DEVELOPER)
                .build();

        category = Category.builder()
                .id(1L)
                .name("Productivity")
                .description("Productivity apps")
                .build();

        app = App.builder()
                .id(1L)
                .name("TaskMaster")
                .description("A task management application")
                .version("1.0.0")
                .price(BigDecimal.ZERO)
                .averageRating(0.0)
                .totalDownloads(0L)
                .published(false)
                .developer(developer)
                .category(category)
                .build();

        appRequest = new AppRequest();
        appRequest.setName("TaskMaster");
        appRequest.setDescription("A task management application");
        appRequest.setVersion("1.0.0");
        appRequest.setPrice(BigDecimal.ZERO);
        appRequest.setCategoryId(1L);
    }

    @Test
    @DisplayName("createApp - success for valid developer")
    void createApp_ShouldReturnAppResponse_WhenValidRequest() {
        when(userRepository.findByUsername("devuser")).thenReturn(Optional.of(developer));
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(category));
        when(appRepository.save(any(App.class))).thenReturn(app);

        AppResponse response = appService.createApp(appRequest, "devuser");

        assertThat(response).isNotNull();
        assertThat(response.getName()).isEqualTo("TaskMaster");
        assertThat(response.getDeveloperName()).isEqualTo("devuser");
        assertThat(response.getCategoryName()).isEqualTo("Productivity");
        verify(appRepository).save(any(App.class));
    }

    @Test
    @DisplayName("createApp - throws ResourceNotFoundException when category not found")
    void createApp_ShouldThrow_WhenCategoryNotFound() {
        when(userRepository.findByUsername("devuser")).thenReturn(Optional.of(developer));
        when(categoryRepository.findById(99L)).thenReturn(Optional.empty());
        appRequest.setCategoryId(99L);

        assertThatThrownBy(() -> appService.createApp(appRequest, "devuser"))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("updateApp - throws UnauthorizedException when not the owner")
    void updateApp_ShouldThrow_WhenNotOwner() {
        when(appRepository.findById(1L)).thenReturn(Optional.of(app));

        assertThatThrownBy(() -> appService.updateApp(1L, appRequest, "otheruser"))
                .isInstanceOf(UnauthorizedException.class)
                .hasMessageContaining("not the owner");
    }

    @Test
    @DisplayName("getAppById - throws ResourceNotFoundException when not found")
    void getAppById_ShouldThrow_WhenNotFound() {
        when(appRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> appService.getAppById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getAllPublishedApps - returns only published apps")
    void getAllPublishedApps_ShouldReturnPublishedOnly() {
        app.setPublished(true);
        when(appRepository.findByPublishedTrue()).thenReturn(List.of(app));

        List<AppResponse> result = appService.getAllPublishedApps();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).isPublished()).isTrue();
    }

    @Test
    @DisplayName("publishApp - sets published to true")
    void publishApp_ShouldPublishApp_WhenOwner() {
        when(appRepository.findById(1L)).thenReturn(Optional.of(app));
        app.setPublished(true);
        when(appRepository.save(any(App.class))).thenReturn(app);

        AppResponse response = appService.publishApp(1L, "devuser");

        assertThat(response.isPublished()).isTrue();
        verify(appRepository).save(any(App.class));
    }

    @Test
    @DisplayName("deleteApp - throws UnauthorizedException when not owner")
    void deleteApp_ShouldThrow_WhenNotOwner() {
        when(appRepository.findById(1L)).thenReturn(Optional.of(app));

        assertThatThrownBy(() -> appService.deleteApp(1L, "someoneelse"))
                .isInstanceOf(UnauthorizedException.class);
        verify(appRepository, never()).delete(any());
    }

    @Test
    @DisplayName("searchApps - returns matching apps")
    void searchApps_ShouldReturnResults() {
        when(appRepository.searchByKeyword("task")).thenReturn(List.of(app));

        List<AppResponse> result = appService.searchApps("task");

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getName()).contains("Task");
    }
}
