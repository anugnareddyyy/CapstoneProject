package com.appverse.service;

import com.appverse.dto.request.ReviewRequest;
import com.appverse.dto.response.ReviewResponse;
import com.appverse.entity.*;
import com.appverse.exception.DuplicateResourceException;
import com.appverse.exception.UnauthorizedException;
import com.appverse.repository.AppRepository;
import com.appverse.repository.ReviewRepository;
import com.appverse.repository.UserRepository;
import com.appverse.service.impl.ReviewServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("ReviewService Unit Tests")
class ReviewServiceTest {

    @Mock private ReviewRepository reviewRepository;
    @Mock private UserRepository userRepository;
    @Mock private AppRepository appRepository;

    @InjectMocks
    private ReviewServiceImpl reviewService;

    private User user;
    private App app;
    private Review review;
    private ReviewRequest reviewRequest;

    @BeforeEach
    void setUp() {
        Category category = Category.builder()
                .id(1L).name("Games").build();

        user = User.builder()
                .id(1L).username("alice").email("alice@test.com").role(Role.USER).build();

        User developer = User.builder()
                .id(2L).username("devuser").role(Role.DEVELOPER).build();

        app = App.builder()
                .id(1L).name("SuperApp").description("Great app")
                .version("1.0.0").price(BigDecimal.ZERO)
                .averageRating(0.0).totalDownloads(0L)
                .developer(developer).category(category).build();

        review = Review.builder()
                .id(1L).content("This app is absolutely great and amazing!")
                .rating(5).sentiment("POSITIVE").sentimentScore(0.8)
                .user(user).app(app).build();

        reviewRequest = new ReviewRequest();
        reviewRequest.setContent("This app is absolutely great and amazing!");
        reviewRequest.setRating(5);
        reviewRequest.setAppId(1L);
    }

    @Test
    @DisplayName("createReview - successfully creates with positive sentiment")
    void createReview_ShouldReturnResponse_WithPositiveSentiment() {
        when(userRepository.findByUsername("alice")).thenReturn(Optional.of(user));
        when(appRepository.findById(1L)).thenReturn(Optional.of(app));
        when(reviewRepository.existsByUserIdAndAppId(1L, 1L)).thenReturn(false);
        when(reviewRepository.save(any(Review.class))).thenReturn(review);
        when(reviewRepository.getAverageRatingByAppId(1L)).thenReturn(5.0);
        when(appRepository.save(any(App.class))).thenReturn(app);

        ReviewResponse response = reviewService.createReview(reviewRequest, "alice");

        assertThat(response).isNotNull();
        assertThat(response.getRating()).isEqualTo(5);
        assertThat(response.getSentiment()).isEqualTo("POSITIVE");
        verify(reviewRepository).save(any(Review.class));
    }

    @Test
    @DisplayName("createReview - throws DuplicateResourceException when already reviewed")
    void createReview_ShouldThrow_WhenAlreadyReviewed() {
        when(userRepository.findByUsername("alice")).thenReturn(Optional.of(user));
        when(appRepository.findById(1L)).thenReturn(Optional.of(app));
        when(reviewRepository.existsByUserIdAndAppId(1L, 1L)).thenReturn(true);

        assertThatThrownBy(() -> reviewService.createReview(reviewRequest, "alice"))
                .isInstanceOf(DuplicateResourceException.class)
                .hasMessageContaining("already reviewed");
        verify(reviewRepository, never()).save(any());
    }

    @Test
    @DisplayName("deleteReview - throws UnauthorizedException when not author")
    void deleteReview_ShouldThrow_WhenNotAuthor() {
        when(reviewRepository.findById(1L)).thenReturn(Optional.of(review));

        assertThatThrownBy(() -> reviewService.deleteReview(1L, "otheruser"))
                .isInstanceOf(UnauthorizedException.class)
                .hasMessageContaining("not the author");
        verify(reviewRepository, never()).delete(any());
    }

    @Test
    @DisplayName("getSentimentAnalysis - returns sentiment map for app")
    void getSentimentAnalysis_ShouldReturnMap() {
        List<Object[]> mockResults = List.of(
                new Object[]{"POSITIVE", 10L},
                new Object[]{"NEGATIVE", 2L}
        );
        when(reviewRepository.getSentimentCountByAppId(1L)).thenReturn(mockResults);

        Map<String, Long> result = reviewService.getSentimentAnalysis(1L);

        assertThat(result.get("POSITIVE")).isEqualTo(10L);
        assertThat(result.get("NEGATIVE")).isEqualTo(2L);
        assertThat(result.get("NEUTRAL")).isEqualTo(0L);
    }

    @Test
    @DisplayName("flagReview - sets flagged and reason")
    void flagReview_ShouldSetFlaggedTrue() {
        when(reviewRepository.findById(1L)).thenReturn(Optional.of(review));
        review.setFlagged(true);
        review.setFlagReason("Spam content");
        when(reviewRepository.save(any(Review.class))).thenReturn(review);

        ReviewResponse response = reviewService.flagReview(1L, "Spam content");

        assertThat(response.isFlagged()).isTrue();
        assertThat(response.getFlagReason()).isEqualTo("Spam content");
    }

    @Test
    @DisplayName("getReviewsByApp - returns approved reviews only")
    void getReviewsByApp_ShouldReturnApprovedReviews() {
        when(reviewRepository.findApprovedReviewsByAppId(1L)).thenReturn(List.of(review));

        List<ReviewResponse> result = reviewService.getReviewsByApp(1L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getAppId()).isEqualTo(1L);
    }
}
