import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/common/ProtectedRoute';
import Navbar from './components/layout/Navbar';

// Pages
import LoginPage from './pages/auth/LoginPage';
import RegisterPage from './pages/auth/RegisterPage';
import MarketplacePage from './pages/apps/MarketplacePage';
import AppDetailPage from './pages/apps/AppDetailPage';
import AIRecommendationsPage from './pages/ai/AIRecommendationsPage';
import DeveloperConsolePage from './pages/developer/DeveloperConsolePage';
import AdminDashboard from './pages/admin/AdminDashboard';
import ReviewDashboardPage from './pages/reviews/ReviewDashboardPage';

const UnauthorizedPage = () => (
  <div style={{ color: '#fff', textAlign: 'center', padding: 80, background: '#0a0a0f', minHeight: '100vh' }}>
    <div style={{ fontSize: 48, marginBottom: 16 }}>🚫</div>
    <h1 style={{ fontSize: 28, marginBottom: 12 }}>Access Denied</h1>
    <p style={{ color: '#8b8da0' }}>You don't have permission to view this page.</p>
  </div>
);

const NotFoundPage = () => (
  <div style={{ color: '#fff', textAlign: 'center', padding: 80, background: '#0a0a0f', minHeight: '100vh' }}>
    <div style={{ fontSize: 64, marginBottom: 16 }}>404</div>
    <h1 style={{ fontSize: 28, color: '#7c6af7', marginBottom: 12 }}>Page not found</h1>
    <p style={{ color: '#8b8da0' }}>The page you're looking for doesn't exist.</p>
  </div>
);

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div style={{ fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif" }}>
          <Navbar />
          <Routes>
            {/* Public */}
            <Route path="/" element={<Navigate to="/apps" replace />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/apps" element={<MarketplacePage />} />
            <Route path="/apps/:id" element={<AppDetailPage />} />

            {/* Authenticated Users */}
            <Route path="/ai/recommendations" element={
              <ProtectedRoute>
                <AIRecommendationsPage />
              </ProtectedRoute>
            } />

            {/* Developer & Admin */}
            <Route path="/developer" element={
              <ProtectedRoute requiredRole={['DEVELOPER', 'ADMIN']}>
                <DeveloperConsolePage />
              </ProtectedRoute>
            } />

            <Route path="/my-reviews" element={
              <ProtectedRoute>
                <ReviewDashboardPage />
              </ProtectedRoute>
            } />

            {/* Admin Only */}
            <Route path="/admin" element={
              <ProtectedRoute requiredRole="ADMIN">
                <AdminDashboard />
              </ProtectedRoute>
            } />

            {/* Misc */}
            <Route path="/unauthorized" element={<UnauthorizedPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
