import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT token to every request
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// Handle 401 globally
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// ── Auth ──────────────────────────────────────────────
export const authAPI = {
  register: (data) => api.post('/api/auth/register', data),
  login: (data) => api.post('/api/auth/login', data),
  me: () => api.get('/api/auth/me'),
};

// ── Apps ──────────────────────────────────────────────
export const appAPI = {
  getAll: () => api.get('/api/apps'),
  getById: (id) => api.get(`/api/apps/${id}`),
  search: (keyword) => api.get(`/api/apps/search?keyword=${keyword}`),
  getByCategory: (id) => api.get(`/api/apps/category/${id}`),
  getFeatured: () => api.get('/api/apps/featured'),
  getTrending: () => api.get('/api/apps/trending'),
  getSimilar: (id) => api.get(`/api/apps/${id}/similar`),
  getMyApps: () => api.get('/api/apps/my-apps'),
  create: (data) => api.post('/api/apps', data),
  update: (id, data) => api.put(`/api/apps/${id}`, data),
  delete: (id) => api.delete(`/api/apps/${id}`),
  publish: (id) => api.put(`/api/apps/${id}/publish`),
  download: (id) => api.post(`/api/apps/${id}/download`),
};

// ── Categories ────────────────────────────────────────
export const categoryAPI = {
  getAll: () => api.get('/api/categories'),
  getById: (id) => api.get(`/api/categories/${id}`),
  create: (data) => api.post('/api/categories', data),
  update: (id, data) => api.put(`/api/categories/${id}`, data),
  delete: (id) => api.delete(`/api/categories/${id}`),
};

// ── Reviews ───────────────────────────────────────────
export const reviewAPI = {
  getByApp: (appId) => api.get(`/api/reviews/app/${appId}`),
  getMyReviews: () => api.get('/api/reviews/my-reviews'),
  create: (data) => api.post('/api/reviews', data),
  update: (id, data) => api.put(`/api/reviews/${id}`, data),
  delete: (id) => api.delete(`/api/reviews/${id}`),
  getSentiment: (appId) => api.get(`/api/reviews/app/${appId}/sentiment`),
  getFlagged: () => api.get('/api/reviews/flagged'),
  flag: (id, reason) => api.put(`/api/reviews/${id}/flag?reason=${reason}`),
};

// ── AI ────────────────────────────────────────────────
export const aiAPI = {
  getRecommendations: () => api.get('/api/ai/recommendations'),
  getSimilar: (appId) => api.get(`/api/ai/similar/${appId}`),
  getTrending: () => api.get('/api/ai/trending'),
  analyzeSentiment: (text) => api.post('/api/ai/analyze-sentiment', { text }),
  getAnalytics: (appId) => api.get(`/api/ai/analytics/${appId}`),
};

// ── Admin ─────────────────────────────────────────────
export const adminAPI = {
  getUsers: () => api.get('/api/admin/users'),
  getUserById: (id) => api.get(`/api/admin/users/${id}`),
  toggleActive: (id) => api.put(`/api/admin/users/${id}/toggle-active`),
  changeRole: (id, role) => api.put(`/api/admin/users/${id}/role?role=${role}`),
  getStats: () => api.get('/api/admin/stats'),
};

export default api;
