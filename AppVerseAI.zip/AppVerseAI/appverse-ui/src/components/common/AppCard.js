import React from 'react';
import { Link } from 'react-router-dom';

const StarRating = ({ rating }) => {
  return (
    <span style={{ color: '#f5a623', fontSize: 13 }}>
      {'★'.repeat(Math.round(rating))}{'☆'.repeat(5 - Math.round(rating))}
      <span style={{ color: '#8b8da0', marginLeft: 4 }}>{rating?.toFixed(1)}</span>
    </span>
  );
};

const AppCard = ({ app }) => {
  const icon = app.iconUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(app.name)}&background=7c6af7&color=fff&size=80`;

  return (
    <Link to={`/apps/${app.id}`} style={styles.card}>
      <div style={styles.iconWrap}>
        <img src={icon} alt={app.name} style={styles.icon} />
        {app.featured && <span style={styles.featuredBadge}>Featured</span>}
      </div>
      <div style={styles.body}>
        <div style={styles.name}>{app.name}</div>
        <div style={styles.dev}>by {app.developerName}</div>
        <div style={styles.category}>{app.categoryName}</div>
        <div style={styles.meta}>
          <StarRating rating={app.averageRating} />
          <span style={styles.downloads}>↓ {app.totalDownloads?.toLocaleString()}</span>
        </div>
        <div style={styles.price}>
          {app.price === 0 || app.price === '0.00' ? (
            <span style={styles.free}>Free</span>
          ) : (
            <span style={styles.priceTag}>${app.price}</span>
          )}
        </div>
      </div>
    </Link>
  );
};

const styles = {
  card: {
    textDecoration: 'none', display: 'flex', flexDirection: 'column',
    background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 16,
    overflow: 'hidden', transition: 'transform 0.2s, border-color 0.2s',
    cursor: 'pointer',
  },
  iconWrap: { position: 'relative', background: '#0f0f1a', padding: 20, display: 'flex', justifyContent: 'center' },
  icon: { width: 72, height: 72, borderRadius: 16, objectFit: 'cover' },
  featuredBadge: { position: 'absolute', top: 10, right: 10, background: '#7c6af7', color: '#fff', fontSize: 10, fontWeight: 700, padding: '3px 8px', borderRadius: 20, textTransform: 'uppercase', letterSpacing: 0.5 },
  body: { padding: '14px 16px', flex: 1, display: 'flex', flexDirection: 'column', gap: 4 },
  name: { color: '#ffffff', fontWeight: 700, fontSize: 15, lineHeight: 1.3 },
  dev: { color: '#8b8da0', fontSize: 12 },
  category: { color: '#7c6af7', fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 },
  meta: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 6 },
  downloads: { color: '#8b8da0', fontSize: 12 },
  price: { marginTop: 8 },
  free: { color: '#4ade80', fontWeight: 700, fontSize: 13 },
  priceTag: { color: '#f5a623', fontWeight: 700, fontSize: 13 },
};

export default AppCard;
