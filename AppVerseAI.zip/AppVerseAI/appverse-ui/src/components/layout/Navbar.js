import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const Navbar = () => {
  const { isAuthenticated, user, logout, isAdmin, isDeveloper } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const isActive = (path) => location.pathname.startsWith(path);

  return (
    <nav style={styles.nav}>
      <div style={styles.container}>
        {/* Brand */}
        <Link to="/" style={styles.brand}>
          <span style={styles.brandIcon}>⬡</span>
          <span>AppVerse <span style={styles.brandAI}>AI</span></span>
        </Link>

        {/* Desktop Links */}
        <div style={styles.links}>
          <Link to="/apps" style={isActive('/apps') ? styles.linkActive : styles.link}>Marketplace</Link>
          {isAuthenticated && (
            <Link to="/ai/recommendations" style={isActive('/ai') ? styles.linkActive : styles.link}>
              ✦ For You
            </Link>
          )}
          {isDeveloper && (
            <Link to="/developer" style={isActive('/developer') ? styles.linkActive : styles.link}>Console</Link>
          )}
          {isAdmin && (
            <Link to="/admin" style={isActive('/admin') ? styles.linkActive : styles.link}>Admin</Link>
          )}
        </div>

        {/* Right Side */}
        <div style={styles.right}>
          {isAuthenticated ? (
            <div style={styles.userMenu}>
              <button onClick={() => setMenuOpen(!menuOpen)} style={styles.avatar}>
                {user?.username?.[0]?.toUpperCase()}
              </button>
              {menuOpen && (
                <div style={styles.dropdown}>
                  <div style={styles.dropdownHeader}>
                    <div style={styles.dropdownName}>{user?.username}</div>
                    <div style={styles.dropdownRole}>{user?.role}</div>
                  </div>
                  <Link to="/profile" style={styles.dropdownItem} onClick={() => setMenuOpen(false)}>Profile</Link>
                  <Link to="/my-reviews" style={styles.dropdownItem} onClick={() => setMenuOpen(false)}>My Reviews</Link>
                  <hr style={styles.divider} />
                  <button onClick={handleLogout} style={styles.dropdownItemBtn}>Sign out</button>
                </div>
              )}
            </div>
          ) : (
            <div style={styles.authLinks}>
              <Link to="/login" style={styles.loginBtn}>Sign in</Link>
              <Link to="/register" style={styles.registerBtn}>Get started</Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

const styles = {
  nav: { background: '#0a0a0f', borderBottom: '1px solid #1e1e2e', position: 'sticky', top: 0, zIndex: 100 },
  container: { maxWidth: 1200, margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', height: 64, gap: 32 },
  brand: { textDecoration: 'none', color: '#fff', fontSize: 20, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8, letterSpacing: '-0.5px' },
  brandIcon: { fontSize: 22, color: '#7c6af7' },
  brandAI: { color: '#7c6af7', fontSize: 18 },
  links: { display: 'flex', gap: 4, flex: 1 },
  link: { textDecoration: 'none', color: '#8b8da0', padding: '6px 14px', borderRadius: 8, fontSize: 14, fontWeight: 500, transition: 'color 0.2s' },
  linkActive: { textDecoration: 'none', color: '#fff', padding: '6px 14px', borderRadius: 8, fontSize: 14, fontWeight: 500, background: '#1a1a2e' },
  right: { marginLeft: 'auto' },
  authLinks: { display: 'flex', gap: 10 },
  loginBtn: { textDecoration: 'none', color: '#8b8da0', padding: '8px 16px', borderRadius: 8, fontSize: 14, fontWeight: 500 },
  registerBtn: { textDecoration: 'none', color: '#fff', padding: '8px 18px', borderRadius: 8, fontSize: 14, fontWeight: 600, background: '#7c6af7' },
  userMenu: { position: 'relative' },
  avatar: { width: 36, height: 36, borderRadius: '50%', background: '#7c6af7', border: 'none', color: '#fff', fontSize: 15, fontWeight: 700, cursor: 'pointer' },
  dropdown: { position: 'absolute', right: 0, top: 44, background: '#12121e', border: '1px solid #2a2a3e', borderRadius: 12, minWidth: 180, boxShadow: '0 8px 32px rgba(0,0,0,0.4)', zIndex: 200 },
  dropdownHeader: { padding: '14px 16px', borderBottom: '1px solid #1e1e2e' },
  dropdownName: { color: '#fff', fontWeight: 600, fontSize: 14 },
  dropdownRole: { color: '#7c6af7', fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 1, marginTop: 2 },
  dropdownItem: { display: 'block', textDecoration: 'none', color: '#c0c0d0', padding: '10px 16px', fontSize: 14 },
  dropdownItemBtn: { display: 'block', width: '100%', textAlign: 'left', background: 'none', border: 'none', color: '#ff6b6b', padding: '10px 16px', fontSize: 14, cursor: 'pointer' },
  divider: { border: 'none', borderTop: '1px solid #1e1e2e', margin: '4px 0' },
};

export default Navbar;
