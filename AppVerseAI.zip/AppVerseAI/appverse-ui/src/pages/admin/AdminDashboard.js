import React, { useState, useEffect } from 'react';
import { adminAPI } from '../../api';

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [flaggedReviews, setFlaggedReviews] = useState([]);
  const [tab, setTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const [statsRes, usersRes, flaggedRes] = await Promise.all([
          adminAPI.getStats(),
          adminAPI.getUsers(),
          adminAPI.getUsers(), // placeholder; flagged from review endpoint
        ]);
        setStats(statsRes.data.data);
        setUsers(usersRes.data.data || []);
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    };
    load();
  }, []);

  const handleToggleActive = async (id) => {
    try {
      await adminAPI.toggleActive(id);
      const res = await adminAPI.getUsers();
      setUsers(res.data.data || []);
      setMsg('User status updated');
    } catch (e) { setMsg('Failed to update'); }
  };

  const handleChangeRole = async (id, role) => {
    try {
      await adminAPI.changeRole(id, role);
      const res = await adminAPI.getUsers();
      setUsers(res.data.data || []);
      setMsg('Role updated');
    } catch (e) { setMsg('Failed to update role'); }
  };

  const roleColors = { ADMIN: '#ff6b6b', DEVELOPER: '#7c6af7', USER: '#4ade80' };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <h1 style={styles.title}>Admin Dashboard</h1>

        {/* Tabs */}
        <div style={styles.tabs}>
          {['overview', 'users'].map(t => (
            <button key={t} onClick={() => setTab(t)}
              style={tab === t ? styles.tabActive : styles.tab}>
              {t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>

        {msg && <div style={styles.msg}>{msg}</div>}

        {loading ? (
          <div style={styles.loading}>Loading dashboard...</div>
        ) : tab === 'overview' ? (
          <>
            <div style={styles.statsGrid}>
              {stats && Object.entries(stats).map(([key, val]) => (
                <div key={key} style={styles.statCard}>
                  <div style={styles.statVal}>{val}</div>
                  <div style={styles.statLabel}>{key.replace(/([A-Z])/g, ' $1').trim()}</div>
                </div>
              ))}
            </div>

            {/* Users table preview */}
            <div style={styles.tableCard}>
              <h2 style={styles.sectionTitle}>Recent Users</h2>
              <table style={styles.table}>
                <thead>
                  <tr>
                    {['ID', 'Username', 'Email', 'Role', 'Status'].map(h => (
                      <th key={h} style={styles.th}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {users.slice(0, 5).map(u => (
                    <tr key={u.id} style={styles.tr}>
                      <td style={styles.td}>{u.id}</td>
                      <td style={styles.td}>{u.username}</td>
                      <td style={styles.td}>{u.email}</td>
                      <td style={styles.td}>
                        <span style={{ ...styles.roleBadge, background: roleColors[u.role] + '22', color: roleColors[u.role] }}>
                          {u.role}
                        </span>
                      </td>
                      <td style={styles.td}>
                        <span style={{ color: u.active ? '#4ade80' : '#ff6b6b', fontWeight: 600, fontSize: 12 }}>
                          {u.active ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          /* Users Tab */
          <div style={styles.tableCard}>
            <h2 style={styles.sectionTitle}>All Users ({users.length})</h2>
            <table style={styles.table}>
              <thead>
                <tr>
                  {['ID', 'Username', 'Email', 'Role', 'Status', 'Actions'].map(h => (
                    <th key={h} style={styles.th}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {users.map(u => (
                  <tr key={u.id} style={styles.tr}>
                    <td style={styles.td}>{u.id}</td>
                    <td style={styles.td}>{u.username}</td>
                    <td style={styles.td}>{u.email}</td>
                    <td style={styles.td}>
                      <select
                        value={u.role}
                        onChange={e => handleChangeRole(u.id, e.target.value)}
                        style={styles.roleSelect}
                      >
                        <option>USER</option>
                        <option>DEVELOPER</option>
                        <option>ADMIN</option>
                      </select>
                    </td>
                    <td style={styles.td}>
                      <span style={{ color: u.active ? '#4ade80' : '#ff6b6b', fontWeight: 600, fontSize: 12 }}>
                        {u.active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td style={styles.td}>
                      <button onClick={() => handleToggleActive(u.id)}
                        style={{ ...styles.actionBtn, color: u.active ? '#ff6b6b' : '#4ade80', borderColor: u.active ? '#ff6b6b' : '#4ade80' }}>
                        {u.active ? 'Deactivate' : 'Activate'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  page: { background: '#0a0a0f', minHeight: '100vh', paddingBottom: 60 },
  container: { maxWidth: 1200, margin: '0 auto', padding: '40px 24px' },
  title: { color: '#fff', fontSize: 28, fontWeight: 800, marginBottom: 28 },
  tabs: { display: 'flex', gap: 4, marginBottom: 32 },
  tab: { background: '#12121e', border: '1px solid #1e1e2e', color: '#8b8da0', padding: '9px 22px', borderRadius: 10, fontSize: 14, cursor: 'pointer', fontWeight: 500 },
  tabActive: { background: '#7c6af7', border: '1px solid #7c6af7', color: '#fff', padding: '9px 22px', borderRadius: 10, fontSize: 14, cursor: 'pointer', fontWeight: 700 },
  msg: { background: '#1a2a1a', color: '#4ade80', padding: '10px 16px', borderRadius: 10, fontSize: 14, marginBottom: 20 },
  loading: { color: '#8b8da0', textAlign: 'center', padding: 40 },
  statsGrid: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 40 },
  statCard: { background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 14, padding: '22px 24px' },
  statVal: { color: '#fff', fontSize: 32, fontWeight: 800 },
  statLabel: { color: '#8b8da0', fontSize: 13, marginTop: 6, textTransform: 'capitalize' },
  tableCard: { background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 20, padding: 28, overflowX: 'auto' },
  sectionTitle: { color: '#fff', fontSize: 18, fontWeight: 700, margin: '0 0 20px' },
  table: { width: '100%', borderCollapse: 'collapse' },
  th: { color: '#8b8da0', fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, textAlign: 'left', padding: '8px 12px', borderBottom: '1px solid #1e1e2e' },
  tr: { borderBottom: '1px solid #0f0f1a' },
  td: { color: '#c0c0d0', fontSize: 14, padding: '12px 12px' },
  roleBadge: { display: 'inline-block', padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 700 },
  roleSelect: { background: '#0f0f1a', border: '1px solid #2a2a3e', borderRadius: 8, padding: '5px 10px', color: '#fff', fontSize: 12 },
  actionBtn: { background: 'transparent', border: '1px solid', borderRadius: 7, padding: '5px 12px', fontSize: 12, fontWeight: 600, cursor: 'pointer' },
};

export default AdminDashboard;
