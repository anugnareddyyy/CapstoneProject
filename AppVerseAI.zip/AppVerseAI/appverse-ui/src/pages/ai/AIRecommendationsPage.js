import React, { useState, useEffect } from 'react';
import { aiAPI } from '../../api';
import AppCard from '../../components/common/AppCard';

const AIRecommendationsPage = () => {
  const [recommendations, setRecommendations] = useState([]);
  const [trending, setTrending] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sentimentText, setSentimentText] = useState('');
  const [sentimentResult, setSentimentResult] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const [recRes, trendRes] = await Promise.all([
          aiAPI.getRecommendations(),
          aiAPI.getTrending(),
        ]);
        setRecommendations(recRes.data.data || []);
        setTrending(trendRes.data.data || []);
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    };
    load();
  }, []);

  const handleAnalyzeSentiment = async (e) => {
    e.preventDefault();
    if (!sentimentText.trim()) return;
    setAnalyzing(true);
    try {
      const res = await aiAPI.analyzeSentiment(sentimentText);
      setSentimentResult(res.data.data);
    } catch (e) { console.error(e); }
    finally { setAnalyzing(false); }
  };

  const sentimentColors = { POSITIVE: '#4ade80', NEGATIVE: '#ff6b6b', NEUTRAL: '#f5a623' };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        {/* Header */}
        <div style={styles.hero}>
          <div style={styles.heroBadge}>✦ AI Powered</div>
          <h1 style={styles.heroTitle}>Your Personalized Feed</h1>
          <p style={styles.heroSub}>Recommendations tailored to your download history and preferences</p>
        </div>

        {/* Recommendations */}
        <section style={styles.section}>
          <h2 style={styles.sectionTitle}>Recommended For You</h2>
          {loading ? (
            <div style={styles.loading}>Generating recommendations...</div>
          ) : recommendations.length === 0 ? (
            <div style={styles.empty}>Download some apps first to get personalized recommendations!</div>
          ) : (
            <div style={styles.grid}>
              {recommendations.map(app => <AppCard key={app.id} app={app} />)}
            </div>
          )}
        </section>

        {/* Trending */}
        <section style={styles.section}>
          <h2 style={styles.sectionTitle}>🔥 Trending Now</h2>
          <div style={styles.grid}>
            {trending.map(app => <AppCard key={app.id} app={app} />)}
          </div>
        </section>

        {/* Sentiment Analyzer Tool */}
        <section style={styles.section}>
          <h2 style={styles.sectionTitle}>🧠 AI Sentiment Analyzer</h2>
          <p style={styles.toolDesc}>Test our AI by analyzing any text for sentiment.</p>
          <div style={styles.analyzerCard}>
            <form onSubmit={handleAnalyzeSentiment} style={styles.analyzerForm}>
              <textarea
                value={sentimentText}
                onChange={e => setSentimentText(e.target.value)}
                placeholder="Paste a review or any text here to analyze its sentiment..."
                rows={5}
                style={styles.textarea}
              />
              <button type="submit" disabled={analyzing} style={styles.analyzeBtn}>
                {analyzing ? 'Analyzing...' : '✦ Analyze Sentiment'}
              </button>
            </form>

            {sentimentResult && (
              <div style={styles.resultCard}>
                <div style={styles.resultHeader}>
                  <span style={{ ...styles.sentimentBadge, background: sentimentColors[sentimentResult.sentiment] + '22', color: sentimentColors[sentimentResult.sentiment] }}>
                    {sentimentResult.sentiment}
                  </span>
                </div>
                <p style={styles.resultAnalysis}>{sentimentResult.analysis}</p>
                <div style={styles.scoreRow}>
                  <div style={styles.scoreItem}>
                    <div style={{ color: '#4ade80', fontWeight: 700, fontSize: 22 }}>{Math.round(sentimentResult.positiveScore * 100)}%</div>
                    <div style={styles.scoreLabel}>Positive</div>
                  </div>
                  <div style={styles.scoreItem}>
                    <div style={{ color: '#ff6b6b', fontWeight: 700, fontSize: 22 }}>{Math.round(sentimentResult.negativeScore * 100)}%</div>
                    <div style={styles.scoreLabel}>Negative</div>
                  </div>
                  <div style={styles.scoreItem}>
                    <div style={{ color: '#7c6af7', fontWeight: 700, fontSize: 22 }}>{sentimentResult.positiveKeywordsFound + sentimentResult.negativeKeywordsFound}</div>
                    <div style={styles.scoreLabel}>Keywords Found</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};

const styles = {
  page: { background: '#0a0a0f', minHeight: '100vh', paddingBottom: 60 },
  container: { maxWidth: 1200, margin: '0 auto', padding: '40px 24px' },
  hero: { textAlign: 'center', marginBottom: 48 },
  heroBadge: { display: 'inline-block', color: '#7c6af7', background: '#1a1030', border: '1px solid #2a2040', padding: '6px 16px', borderRadius: 20, fontSize: 13, fontWeight: 700, marginBottom: 16 },
  heroTitle: { color: '#fff', fontSize: 36, fontWeight: 800, margin: '0 0 10px', letterSpacing: '-0.5px' },
  heroSub: { color: '#8b8da0', fontSize: 16 },
  section: { marginBottom: 56 },
  sectionTitle: { color: '#fff', fontSize: 22, fontWeight: 700, marginBottom: 20 },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 20 },
  loading: { color: '#8b8da0', textAlign: 'center', padding: 40 },
  empty: { color: '#8b8da0', textAlign: 'center', padding: 40, background: '#12121e', borderRadius: 16, border: '1px solid #1e1e2e' },
  toolDesc: { color: '#8b8da0', fontSize: 14, marginBottom: 20 },
  analyzerCard: { background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 20, padding: 32 },
  analyzerForm: { display: 'flex', flexDirection: 'column', gap: 16 },
  textarea: { background: '#0f0f1a', border: '1px solid #2a2a3e', borderRadius: 12, padding: '14px 16px', color: '#fff', fontSize: 15, resize: 'vertical', outline: 'none', lineHeight: 1.6 },
  analyzeBtn: { background: '#7c6af7', color: '#fff', border: 'none', borderRadius: 10, padding: '13px 28px', fontSize: 15, fontWeight: 700, cursor: 'pointer', alignSelf: 'flex-start' },
  resultCard: { marginTop: 24, background: '#0f0f1a', borderRadius: 16, padding: 24, border: '1px solid #1e1e2e' },
  resultHeader: { marginBottom: 12 },
  sentimentBadge: { display: 'inline-block', padding: '6px 16px', borderRadius: 20, fontWeight: 700, fontSize: 14 },
  resultAnalysis: { color: '#c0c0d0', fontSize: 14, lineHeight: 1.6, margin: '12px 0' },
  scoreRow: { display: 'flex', gap: 32, marginTop: 16 },
  scoreItem: { textAlign: 'center' },
  scoreLabel: { color: '#8b8da0', fontSize: 12, marginTop: 4 },
};

export default AIRecommendationsPage;
