import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { appAPI, reviewAPI } from '../../api';
import { useAuth } from '../../context/AuthContext';
import AppCard from '../../components/common/AppCard';

const AppDetailPage = () => {
  const { id } = useParams();
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();

  const [app, setApp] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [similar, setSimilar] = useState([]);
  const [sentiment, setSentiment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);

  const [reviewForm, setReviewForm] = useState({ content: '', rating: 5 });
  const [submitting, setSubmitting] = useState(false);
  const [reviewMsg, setReviewMsg] = useState('');

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const [appRes, revRes, simRes] = await Promise.all([
          appAPI.getById(id),
          reviewAPI.getByApp(id),
          appAPI.getSimilar(id),
        ]);
        setApp(appRes.data.data);
        setReviews(revRes.data.data || []);
        setSimilar(simRes.data.data || []);

        // Sentiment analysis
        const sentRes = await reviewAPI.getSentiment(id);
        setSentiment(sentRes.data.data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  const handleDownload = async () => {
    if (!isAuthenticated) { navigate('/login'); return; }
    setDownloading(true);
    try {
      await appAPI.download(id);
      const res = await appAPI.getById(id);
      setApp(res.data.data);
    } catch (e) { console.error(e); }
    finally { setDownloading(false); }
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    if (!isAuthenticated) { navigate('/login'); return; }
    setSubmitting(true);
    setReviewMsg('');
    try {
      await reviewAPI.create({ ...reviewForm, appId: Number(id) });
      setReviewMsg('Review submitted successfully!');
      setReviewForm({ content: '', rating: 5 });
      const res = await reviewAPI.getByApp(id);
      setReviews(res.data.data || []);
      const sentRes = await reviewAPI.getSentiment(id);
      setSentiment(sentRes.data.data);
    } catch (e) {
      setReviewMsg(e.response?.data?.message || 'Failed to submit review');
    } finally { setSubmitting(false); }
  };

  if (loading) return <div style={styles.center}>Loading...</div>;
  if (!app) return <div style={styles.center}>App not found.</div>;

  const totalReviews = sentiment ? Object.values(sentiment).reduce((a, b) => a + b, 0) : 0;

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        {/* App Header */}
        <div style={styles.header}>
          <img
            src={app.iconUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(app.name)}&background=7c6af7&color=fff&size=100`}
            alt={app.name} style={styles.icon}
          />
          <div style={styles.info}>
            <div style={styles.category}>{app.categoryName}</div>
            <h1 style={styles.name}>{app.name}</h1>
            <div style={styles.devRow}>by <span style={styles.dev}>{app.developerName}</span></div>
            <div style={styles.metaRow}>
              <span style={styles.rating}>{'★'.repeat(Math.round(app.averageRating))} {app.averageRating?.toFixed(1)}</span>
              <span style={styles.dot}>·</span>
              <span style={styles.meta}>v{app.version}</span>
              <span style={styles.dot}>·</span>
              <span style={styles.meta}>{app.totalDownloads?.toLocaleString()} downloads</span>
            </div>
            <div style={styles.actions}>
              <button onClick={handleDownload} disabled={downloading} style={styles.downloadBtn}>
                {downloading ? 'Downloading...' : app.price === 0 || app.price === '0.00' ? '⬇ Free Download' : `⬇ $${app.price}`}
              </button>
            </div>
          </div>
        </div>

        <div style={styles.body}>
          {/* Left Column */}
          <div style={styles.main}>
            <section style={styles.section}>
              <h2 style={styles.sectionTitle}>About</h2>
              <p style={styles.description}>{app.description}</p>
            </section>

            {app.releaseNotes && (
              <section style={styles.section}>
                <h2 style={styles.sectionTitle}>Release Notes — v{app.version}</h2>
                <p style={styles.description}>{app.releaseNotes}</p>
              </section>
            )}

            {/* Sentiment */}
            {sentiment && totalReviews > 0 && (
              <section style={styles.section}>
                <h2 style={styles.sectionTitle}>Review Sentiment</h2>
                <div style={styles.sentimentRow}>
                  {['POSITIVE', 'NEUTRAL', 'NEGATIVE'].map(s => {
                    const count = sentiment[s] || 0;
                    const pct = totalReviews > 0 ? Math.round((count / totalReviews) * 100) : 0;
                    const colors = { POSITIVE: '#4ade80', NEUTRAL: '#f5a623', NEGATIVE: '#ff6b6b' };
                    return (
                      <div key={s} style={styles.sentimentCard}>
                        <div style={{ ...styles.sentimentBar, background: colors[s], height: `${Math.max(pct, 4)}%` }} />
                        <div style={{ color: colors[s], fontWeight: 700, fontSize: 18 }}>{pct}%</div>
                        <div style={styles.sentimentLabel}>{s}</div>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}

            {/* Reviews */}
            <section style={styles.section}>
              <h2 style={styles.sectionTitle}>Reviews ({reviews.length})</h2>

              {isAuthenticated && (
                <form onSubmit={handleReviewSubmit} style={styles.reviewForm}>
                  <div style={styles.ratingRow}>
                    {[1,2,3,4,5].map(n => (
                      <button key={n} type="button"
                        onClick={() => setReviewForm({...reviewForm, rating: n})}
                        style={{ background:'none', border:'none', fontSize:28, cursor:'pointer',
                          color: n <= reviewForm.rating ? '#f5a623' : '#3a3a4e' }}>★</button>
                    ))}
                  </div>
                  <textarea
                    value={reviewForm.content}
                    onChange={e => setReviewForm({...reviewForm, content: e.target.value})}
                    placeholder="Write your review..."
                    rows={4}
                    style={styles.textarea}
                    required
                  />
                  {reviewMsg && (
                    <div style={{ color: reviewMsg.includes('success') ? '#4ade80' : '#ff6b6b', fontSize: 13 }}>
                      {reviewMsg}
                    </div>
                  )}
                  <button type="submit" disabled={submitting} style={styles.reviewBtn}>
                    {submitting ? 'Submitting...' : 'Post Review'}
                  </button>
                </form>
              )}

              <div style={styles.reviewList}>
                {reviews.length === 0 ? (
                  <p style={styles.empty}>No reviews yet. Be the first!</p>
                ) : reviews.map(r => (
                  <div key={r.id} style={styles.reviewCard}>
                    <div style={styles.reviewHeader}>
                      <div style={styles.reviewAvatar}>{r.username?.[0]?.toUpperCase()}</div>
                      <div>
                        <div style={styles.reviewUser}>{r.username}</div>
                        <div style={styles.reviewDate}>{new Date(r.createdAt).toLocaleDateString()}</div>
                      </div>
                      <div style={{ marginLeft: 'auto' }}>
                        <span style={{ color: '#f5a623' }}>{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</span>
                        <span style={{ ...styles.sentimentBadge, background: r.sentiment === 'POSITIVE' ? '#1a3a2a' : r.sentiment === 'NEGATIVE' ? '#3a1a1a' : '#2a2a1a', color: r.sentiment === 'POSITIVE' ? '#4ade80' : r.sentiment === 'NEGATIVE' ? '#ff6b6b' : '#f5a623' }}>
                          {r.sentiment}
                        </span>
                      </div>
                    </div>
                    <p style={styles.reviewContent}>{r.content}</p>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Sidebar: Similar Apps */}
          {similar.length > 0 && (
            <div style={styles.sidebar}>
              <h3 style={styles.sidebarTitle}>Similar Apps</h3>
              <div style={styles.similarList}>
                {similar.map(a => <AppCard key={a.id} app={a} />)}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const styles = {
  page: { background: '#0a0a0f', minHeight: '100vh', paddingBottom: 60 },
  center: { color: '#8b8da0', textAlign: 'center', padding: 80 },
  container: { maxWidth: 1100, margin: '0 auto', padding: '40px 24px' },
  header: { display: 'flex', gap: 28, alignItems: 'flex-start', marginBottom: 48, background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 20, padding: 32 },
  icon: { width: 100, height: 100, borderRadius: 20, objectFit: 'cover', flexShrink: 0 },
  info: { flex: 1 },
  category: { color: '#7c6af7', fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 },
  name: { color: '#fff', fontSize: 32, fontWeight: 800, margin: '0 0 6px', letterSpacing: '-0.5px' },
  devRow: { color: '#8b8da0', fontSize: 14, marginBottom: 8 },
  dev: { color: '#7c6af7', fontWeight: 600 },
  metaRow: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20 },
  rating: { color: '#f5a623', fontWeight: 600, fontSize: 14 },
  dot: { color: '#3a3a4e' },
  meta: { color: '#8b8da0', fontSize: 14 },
  actions: { display: 'flex', gap: 12 },
  downloadBtn: { background: '#7c6af7', color: '#fff', border: 'none', borderRadius: 10, padding: '12px 28px', fontSize: 16, fontWeight: 700, cursor: 'pointer' },
  body: { display: 'grid', gridTemplateColumns: '1fr 300px', gap: 40 },
  main: {},
  section: { marginBottom: 40 },
  sectionTitle: { color: '#fff', fontSize: 20, fontWeight: 700, marginBottom: 16, paddingBottom: 10, borderBottom: '1px solid #1e1e2e' },
  description: { color: '#c0c0d0', lineHeight: 1.7, fontSize: 15 },
  sentimentRow: { display: 'flex', gap: 16, alignItems: 'flex-end', height: 120 },
  sentimentCard: { flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 },
  sentimentBar: { width: '100%', borderRadius: 6, minHeight: 4 },
  sentimentLabel: { color: '#8b8da0', fontSize: 11, fontWeight: 600, textTransform: 'uppercase' },
  reviewForm: { background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 16, padding: 24, marginBottom: 24, display: 'flex', flexDirection: 'column', gap: 12 },
  ratingRow: { display: 'flex', gap: 4 },
  textarea: { background: '#0f0f1a', border: '1px solid #2a2a3e', borderRadius: 10, padding: '12px 14px', color: '#fff', fontSize: 14, resize: 'vertical', outline: 'none' },
  reviewBtn: { background: '#7c6af7', color: '#fff', border: 'none', borderRadius: 10, padding: '10px 24px', fontSize: 14, fontWeight: 700, cursor: 'pointer', alignSelf: 'flex-start' },
  reviewList: { display: 'flex', flexDirection: 'column', gap: 16 },
  reviewCard: { background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 14, padding: 20 },
  reviewHeader: { display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 },
  reviewAvatar: { width: 36, height: 36, borderRadius: '50%', background: '#2a2a3e', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 14, flexShrink: 0 },
  reviewUser: { color: '#fff', fontWeight: 600, fontSize: 14 },
  reviewDate: { color: '#8b8da0', fontSize: 12 },
  sentimentBadge: { display: 'inline-block', fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 20, marginLeft: 8 },
  reviewContent: { color: '#c0c0d0', fontSize: 14, lineHeight: 1.6, margin: 0 },
  empty: { color: '#8b8da0', fontStyle: 'italic' },
  sidebar: {},
  sidebarTitle: { color: '#fff', fontSize: 16, fontWeight: 700, marginBottom: 16 },
  similarList: { display: 'flex', flexDirection: 'column', gap: 16 },
};

export default AppDetailPage;
