import React, { useState, useEffect } from 'react';
import { appAPI, categoryAPI } from '../../api';
import AppCard from '../../components/common/AppCard';

const MarketplacePage = () => {
  const [apps, setApps] = useState([]);
  const [categories, setCategories] = useState([]);
  const [featured, setFeatured] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(null);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const [appsRes, catsRes, featRes] = await Promise.all([
          appAPI.getAll(),
          categoryAPI.getAll(),
          appAPI.getFeatured(),
        ]);
        setApps(appsRes.data.data || []);
        setCategories(catsRes.data.data || []);
        setFeatured(featRes.data.data || []);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!search.trim()) return;
    try {
      const res = await appAPI.search(search);
      setApps(res.data.data || []);
      setSelectedCategory(null);
    } catch (e) { console.error(e); }
  };

  const handleCategoryFilter = async (catId) => {
    setSelectedCategory(catId);
    try {
      if (catId === null) {
        const res = await appAPI.getAll();
        setApps(res.data.data || []);
      } else {
        const res = await appAPI.getByCategory(catId);
        setApps(res.data.data || []);
      }
    } catch (e) { console.error(e); }
  };

  return (
    <div style={styles.page}>
      {/* Hero */}
      <div style={styles.hero}>
        <h1 style={styles.heroTitle}>Discover Great Apps</h1>
        <p style={styles.heroSub}>Powered by AI recommendations tailored just for you</p>
        <form onSubmit={handleSearch} style={styles.searchForm}>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search apps, games, tools..."
            style={styles.searchInput}
          />
          <button type="submit" style={styles.searchBtn}>Search</button>
        </form>
      </div>

      <div style={styles.container}>
        {/* Featured */}
        {featured.length > 0 && (
          <section style={styles.section}>
            <h2 style={styles.sectionTitle}>⭐ Featured</h2>
            <div style={styles.grid}>
              {featured.map(app => <AppCard key={app.id} app={app} />)}
            </div>
          </section>
        )}

        {/* Category Filter */}
        <div style={styles.filters}>
          <button
            onClick={() => handleCategoryFilter(null)}
            style={selectedCategory === null ? styles.filterActive : styles.filter}
          >All</button>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => handleCategoryFilter(cat.id)}
              style={selectedCategory === cat.id ? styles.filterActive : styles.filter}
            >{cat.name}</button>
          ))}
        </div>

        {/* All Apps */}
        <section style={styles.section}>
          <h2 style={styles.sectionTitle}>All Apps</h2>
          {loading ? (
            <div style={styles.loading}>Loading apps...</div>
          ) : apps.length === 0 ? (
            <div style={styles.empty}>No apps found. Try a different search or category.</div>
          ) : (
            <div style={styles.grid}>
              {apps.map(app => <AppCard key={app.id} app={app} />)}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

const styles = {
  page: { background: '#0a0a0f', minHeight: '100vh' },
  hero: { background: 'linear-gradient(135deg, #12121e 0%, #1a1030 100%)', padding: '64px 24px', textAlign: 'center' },
  heroTitle: { color: '#fff', fontSize: 42, fontWeight: 800, margin: '0 0 12px', letterSpacing: '-1px' },
  heroSub: { color: '#8b8da0', fontSize: 18, margin: '0 0 32px' },
  searchForm: { display: 'flex', maxWidth: 540, margin: '0 auto', gap: 10 },
  searchInput: { flex: 1, background: '#0f0f1a', border: '1px solid #2a2a3e', borderRadius: 12, padding: '14px 18px', color: '#fff', fontSize: 16, outline: 'none' },
  searchBtn: { background: '#7c6af7', color: '#fff', border: 'none', borderRadius: 12, padding: '14px 24px', fontSize: 16, fontWeight: 600, cursor: 'pointer' },
  container: { maxWidth: 1200, margin: '0 auto', padding: '40px 24px' },
  section: { marginBottom: 48 },
  sectionTitle: { color: '#fff', fontSize: 22, fontWeight: 700, marginBottom: 20 },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 20 },
  filters: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 32 },
  filter: { background: '#12121e', border: '1px solid #1e1e2e', color: '#8b8da0', padding: '8px 18px', borderRadius: 20, fontSize: 14, cursor: 'pointer', fontWeight: 500 },
  filterActive: { background: '#7c6af7', border: '1px solid #7c6af7', color: '#fff', padding: '8px 18px', borderRadius: 20, fontSize: 14, cursor: 'pointer', fontWeight: 600 },
  loading: { color: '#8b8da0', textAlign: 'center', padding: 40 },
  empty: { color: '#8b8da0', textAlign: 'center', padding: 40 },
};

export default MarketplacePage;
