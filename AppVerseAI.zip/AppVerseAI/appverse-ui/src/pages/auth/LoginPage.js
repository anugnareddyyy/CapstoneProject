import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const LoginPage = () => {
  const { login, loading, error } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || '/apps';

  const [form, setForm] = useState({ usernameOrEmail: '', password: '' });
  const [formError, setFormError] = useState('');

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const validate = () => {
    if (!form.usernameOrEmail.trim()) return 'Username or email is required';
    if (!form.password) return 'Password is required';
    return '';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const err = validate();
    if (err) { setFormError(err); return; }
    setFormError('');
    const result = await login(form);
    if (result.success) navigate(from, { replace: true });
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.logo}>⬡</div>
        <h1 style={styles.title}>Welcome back</h1>
        <p style={styles.subtitle}>Sign in to AppVerse AI</p>

        {(formError || error) && (
          <div style={styles.errorBox}>{formError || error}</div>
        )}

        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.field}>
            <label style={styles.label}>Username or Email</label>
            <input
              name="usernameOrEmail"
              value={form.usernameOrEmail}
              onChange={handleChange}
              style={styles.input}
              placeholder="john@example.com"
              autoComplete="username"
            />
          </div>
          <div style={styles.field}>
            <label style={styles.label}>Password</label>
            <input
              name="password"
              type="password"
              value={form.password}
              onChange={handleChange}
              style={styles.input}
              placeholder="••••••••"
              autoComplete="current-password"
            />
          </div>
          <button type="submit" style={styles.btn} disabled={loading}>
            {loading ? 'Signing in...' : 'Sign in'}
          </button>
        </form>

        <p style={styles.footer}>
          Don't have an account? <Link to="/register" style={styles.link}>Create one</Link>
        </p>
      </div>
    </div>
  );
};

const styles = {
  page: { minHeight: '100vh', background: '#0a0a0f', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 },
  card: { background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 20, padding: '48px 40px', width: '100%', maxWidth: 420 },
  logo: { fontSize: 40, color: '#7c6af7', textAlign: 'center', marginBottom: 16 },
  title: { color: '#fff', fontSize: 26, fontWeight: 700, textAlign: 'center', margin: '0 0 8px' },
  subtitle: { color: '#8b8da0', fontSize: 14, textAlign: 'center', margin: '0 0 32px' },
  errorBox: { background: '#2a1a1a', border: '1px solid #ff6b6b', color: '#ff6b6b', borderRadius: 10, padding: '10px 14px', fontSize: 14, marginBottom: 20 },
  form: { display: 'flex', flexDirection: 'column', gap: 20 },
  field: { display: 'flex', flexDirection: 'column', gap: 6 },
  label: { color: '#c0c0d0', fontSize: 13, fontWeight: 600 },
  input: { background: '#0f0f1a', border: '1px solid #2a2a3e', borderRadius: 10, padding: '12px 14px', color: '#fff', fontSize: 15, outline: 'none' },
  btn: { background: '#7c6af7', color: '#fff', border: 'none', borderRadius: 10, padding: '14px', fontSize: 16, fontWeight: 700, cursor: 'pointer', marginTop: 4 },
  footer: { color: '#8b8da0', textAlign: 'center', fontSize: 14, marginTop: 24 },
  link: { color: '#7c6af7', textDecoration: 'none', fontWeight: 600 },
};

export default LoginPage;
