import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const RegisterPage = () => {
  const { register, loading, error } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    username: '', email: '', password: '', fullName: '', role: 'USER'
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const validate = () => {
    const errs = {};
    if (!form.username.trim() || form.username.length < 3) errs.username = 'Username must be at least 3 characters';
    if (!form.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) errs.email = 'Valid email required';
    if (form.password.length < 6) errs.password = 'Password must be at least 6 characters';
    if (!form.fullName.trim()) errs.fullName = 'Full name is required';
    return errs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setErrors({});
    const result = await register(form);
    if (result.success) navigate('/apps');
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.logo}>⬡</div>
        <h1 style={styles.title}>Create your account</h1>
        <p style={styles.subtitle}>Join AppVerse AI today</p>

        {error && <div style={styles.errorBox}>{error}</div>}

        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.row}>
            <Field label="Full Name" name="fullName" value={form.fullName} onChange={handleChange} error={errors.fullName} placeholder="Jane Doe" />
            <Field label="Username" name="username" value={form.username} onChange={handleChange} error={errors.username} placeholder="janedoe" />
          </div>
          <Field label="Email" name="email" type="email" value={form.email} onChange={handleChange} error={errors.email} placeholder="jane@example.com" />
          <Field label="Password" name="password" type="password" value={form.password} onChange={handleChange} error={errors.password} placeholder="••••••••" />

          <div style={styles.field}>
            <label style={styles.label}>Account Type</label>
            <select name="role" value={form.role} onChange={handleChange} style={styles.select}>
              <option value="USER">User — Browse & download apps</option>
              <option value="DEVELOPER">Developer — Publish apps</option>
            </select>
          </div>

          <button type="submit" style={styles.btn} disabled={loading}>
            {loading ? 'Creating account...' : 'Create account'}
          </button>
        </form>

        <p style={styles.footer}>
          Already have an account? <Link to="/login" style={styles.link}>Sign in</Link>
        </p>
      </div>
    </div>
  );
};

const Field = ({ label, name, value, onChange, error, type = 'text', placeholder }) => (
  <div style={fieldStyles.field}>
    <label style={fieldStyles.label}>{label}</label>
    <input name={name} type={type} value={value} onChange={onChange}
      style={{ ...fieldStyles.input, ...(error ? fieldStyles.inputError : {}) }}
      placeholder={placeholder} />
    {error && <span style={fieldStyles.error}>{error}</span>}
  </div>
);

const fieldStyles = {
  field: { display: 'flex', flexDirection: 'column', gap: 5 },
  label: { color: '#c0c0d0', fontSize: 13, fontWeight: 600 },
  input: { background: '#0f0f1a', border: '1px solid #2a2a3e', borderRadius: 10, padding: '12px 14px', color: '#fff', fontSize: 14, outline: 'none' },
  inputError: { borderColor: '#ff6b6b' },
  error: { color: '#ff6b6b', fontSize: 12 },
};

const styles = {
  page: { minHeight: '100vh', background: '#0a0a0f', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 },
  card: { background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 20, padding: '48px 40px', width: '100%', maxWidth: 520 },
  logo: { fontSize: 40, color: '#7c6af7', textAlign: 'center', marginBottom: 16 },
  title: { color: '#fff', fontSize: 26, fontWeight: 700, textAlign: 'center', margin: '0 0 8px' },
  subtitle: { color: '#8b8da0', fontSize: 14, textAlign: 'center', margin: '0 0 32px' },
  errorBox: { background: '#2a1a1a', border: '1px solid #ff6b6b', color: '#ff6b6b', borderRadius: 10, padding: '10px 14px', fontSize: 14, marginBottom: 20 },
  form: { display: 'flex', flexDirection: 'column', gap: 18 },
  row: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 },
  field: { display: 'flex', flexDirection: 'column', gap: 6 },
  label: { color: '#c0c0d0', fontSize: 13, fontWeight: 600 },
  select: { background: '#0f0f1a', border: '1px solid #2a2a3e', borderRadius: 10, padding: '12px 14px', color: '#fff', fontSize: 14, outline: 'none' },
  btn: { background: '#7c6af7', color: '#fff', border: 'none', borderRadius: 10, padding: 14, fontSize: 16, fontWeight: 700, cursor: 'pointer', marginTop: 4 },
  footer: { color: '#8b8da0', textAlign: 'center', fontSize: 14, marginTop: 24 },
  link: { color: '#7c6af7', textDecoration: 'none', fontWeight: 600 },
};

export default RegisterPage;
