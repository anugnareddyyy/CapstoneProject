import React, { useState, useEffect } from 'react';
import { appAPI, categoryAPI, aiAPI } from '../../api';
import { useAuth } from '../../context/AuthContext';

const DeveloperConsolePage = () => {
  const { user } = useAuth();
  const [apps, setApps] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [analytics, setAnalytics] = useState({});
  const [msg, setMsg] = useState('');

  const emptyForm = { name: '', description: '', version: '1.0.0', price: '0', iconUrl: '', downloadUrl: '', releaseNotes: '', categoryId: '' };
  const [form, setForm] = useState(emptyForm);

  const loadApps = async () => {
    setLoading(true);
    try {
      const [appsRes, catsRes] = await Promise.all([appAPI.getMyApps(), categoryAPI.getAll()]);
      const myApps = appsRes.data.data || [];
      setApps(myApps);
      setCategories(catsRes.data.data || []);

      // Load analytics for each app
      const analyticsMap = {};
      await Promise.all(myApps.map(async (a) => {
        try {
          const res = await aiAPI.getAnalytics(a.id);
          analyticsMap[a.id] = res.data.data;
        } catch { analyticsMap[a.id] = null; }
      }));
      setAnalytics(analyticsMap);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadApps(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMsg('');
    try {
      const payload = { ...form, price: parseFloat(form.price) || 0, categoryId: Number(form.categoryId) };
      if (editing) {
        await appAPI.update(editing, payload);
        setMsg('App updated successfully!');
      } else {
        await appAPI.create(payload);
        setMsg('App created successfully!');
      }
      setShowForm(false);
      setEditing(null);
      setForm(emptyForm);
      await loadApps();
    } catch (e) {
      setMsg(e.response?.data?.message || 'Operation failed');
    }
  };

  const handleEdit = (app) => {
    setForm({ name: app.name, description: app.description, version: app.version, price: app.price?.toString() || '0', iconUrl: app.iconUrl || '', downloadUrl: app.downloadUrl || '', releaseNotes: app.releaseNotes || '', categoryId: app.categoryId?.toString() || '' });
    setEditing(app.id);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this app?')) return;
    try {
      await appAPI.delete(id);
      await loadApps();
    } catch (e) { setMsg(e.response?.data?.message || 'Delete failed'); }
  };

  const handlePublish = async (id) => {
    try {
      await appAPI.publish(id);
      await loadApps();
    } catch (e) { setMsg(e.response?.data?.message || 'Publish failed'); }
  };

  const totalDownloads = apps.reduce((s, a) => s + (a.totalDownloads || 0), 0);

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        {/* Header */}
        <div style={styles.header}>
          <div>
            <h1 style={styles.title}>Developer Console</h1>
            <p style={styles.subtitle}>Welcome, <span style={styles.username}>{user?.username}</span></p>
          </div>
          <button onClick={() => { setShowForm(!showForm); setEditing(null); setForm(emptyForm); }} style={styles.createBtn}>
            {showForm ? '✕ Cancel' : '+ New App'}
          </button>
        </div>

        {/* Stats */}
        <div style={styles.stats}>
          {[{ label: 'Total Apps', value: apps.length }, { label: 'Published', value: apps.filter(a => a.published).length }, { label: 'Total Downloads', value: totalDownloads.toLocaleString() }, { label: 'Avg Rating', value: apps.length ? (apps.reduce((s, a) => s + (a.averageRating || 0), 0) / apps.length).toFixed(1) : '—' }]
            .map(s => (
              <div key={s.label} style={styles.statCard}>
                <div style={styles.statValue}>{s.value}</div>
                <div style={styles.statLabel}>{s.label}</div>
              </div>
            ))}
        </div>

        {msg && <div style={{ ...styles.msg, color: msg.includes('success') ? '#4ade80' : '#ff6b6b' }}>{msg}</div>}

        {/* Create/Edit Form */}
        {showForm && (
          <div style={styles.formCard}>
            <h2 style={styles.formTitle}>{editing ? 'Edit App' : 'New App'}</h2>
            <form onSubmit={handleSubmit} style={styles.form}>
              <div style={styles.row}>
                <FormField label="App Name *" value={form.name} onChange={v => setForm({...form, name: v})} placeholder="My Amazing App" />
                <FormField label="Version *" value={form.version} onChange={v => setForm({...form, version: v})} placeholder="1.0.0" />
              </div>
              <FormField label="Description *" value={form.description} onChange={v => setForm({...form, description: v})} placeholder="Describe your app..." textarea />
              <div style={styles.row}>
                <FormField label="Price ($)" value={form.price} onChange={v => setForm({...form, price: v})} placeholder="0" type="number" />
                <div style={styles.field}>
                  <label style={styles.label}>Category *</label>
                  <select value={form.categoryId} onChange={e => setForm({...form, categoryId: e.target.value})} style={styles.select} required>
                    <option value="">Select category</option>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
              </div>
              <div style={styles.row}>
                <FormField label="Icon URL" value={form.iconUrl} onChange={v => setForm({...form, iconUrl: v})} placeholder="https://..." />
                <FormField label="Download URL" value={form.downloadUrl} onChange={v => setForm({...form, downloadUrl: v})} placeholder="https://..." />
              </div>
              <FormField label="Release Notes" value={form.releaseNotes} onChange={v => setForm({...form, releaseNotes: v})} placeholder="What's new in this version..." textarea />
              <button type="submit" style={styles.submitBtn}>{editing ? 'Update App' : 'Create App'}</button>
            </form>
          </div>
        )}

        {/* My Apps */}
        <section>
          <h2 style={styles.sectionTitle}>My Apps ({apps.length})</h2>
          {loading ? (
            <div style={styles.empty}>Loading your apps...</div>
          ) : apps.length === 0 ? (
            <div style={styles.empty}>No apps yet. Create your first app!</div>
          ) : (
            <div style={styles.appList}>
              {apps.map(app => (
                <div key={app.id} style={styles.appRow}>
                  <img src={app.iconUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(app.name)}&background=7c6af7&color=fff&size=48`} alt={app.name} style={styles.appIcon} />
                  <div style={styles.appInfo}>
                    <div style={styles.appName}>{app.name}</div>
                    <div style={styles.appMeta}>v{app.version} · {app.categoryName} · ↓ {app.totalDownloads} · ★ {app.averageRating?.toFixed(1)}</div>
                    {analytics[app.id] && (
                      <div style={styles.prediction}>📈 Predicted next month: {analytics[app.id].downloadPrediction} downloads</div>
                    )}
                  </div>
                  <div style={styles.appActions}>
                    {!app.published && (
                      <button onClick={() => handlePublish(app.id)} style={styles.publishBtn}>Publish</button>
                    )}
                    {app.published && <span style={styles.publishedBadge}>● Live</span>}
                    <button onClick={() => handleEdit(app)} style={styles.editBtn}>Edit</button>
                    <button onClick={() => handleDelete(app.id)} style={styles.deleteBtn}>Delete</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

const FormField = ({ label, value, onChange, placeholder, type = 'text', textarea }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
    <label style={{ color: '#c0c0d0', fontSize: 13, fontWeight: 600 }}>{label}</label>
    {textarea ? (
      <textarea value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={3}
        style={{ background: '#0f0f1a', border: '1px solid #2a2a3e', borderRadius: 10, padding: '11px 13px', color: '#fff', fontSize: 14, outline: 'none', resize: 'vertical' }} />
    ) : (
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        style={{ background: '#0f0f1a', border: '1px solid #2a2a3e', borderRadius: 10, padding: '11px 13px', color: '#fff', fontSize: 14, outline: 'none' }} />
    )}
  </div>
);

const styles = {
  page: { background: '#0a0a0f', minHeight: '100vh', paddingBottom: 60 },
  container: { maxWidth: 1100, margin: '0 auto', padding: '40px 24px' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 32 },
  title: { color: '#fff', fontSize: 28, fontWeight: 800, margin: 0 },
  subtitle: { color: '#8b8da0', fontSize: 14, margin: '6px 0 0' },
  username: { color: '#7c6af7', fontWeight: 600 },
  createBtn: { background: '#7c6af7', color: '#fff', border: 'none', borderRadius: 10, padding: '11px 22px', fontSize: 15, fontWeight: 700, cursor: 'pointer' },
  stats: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 32 },
  statCard: { background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 14, padding: '20px 24px' },
  statValue: { color: '#fff', fontSize: 28, fontWeight: 800 },
  statLabel: { color: '#8b8da0', fontSize: 13, marginTop: 4 },
  msg: { marginBottom: 20, fontSize: 14, fontWeight: 600 },
  formCard: { background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 20, padding: 32, marginBottom: 40 },
  formTitle: { color: '#fff', fontSize: 18, fontWeight: 700, margin: '0 0 24px' },
  form: { display: 'flex', flexDirection: 'column', gap: 20 },
  row: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 },
  field: { display: 'flex', flexDirection: 'column', gap: 6 },
  label: { color: '#c0c0d0', fontSize: 13, fontWeight: 600 },
  select: { background: '#0f0f1a', border: '1px solid #2a2a3e', borderRadius: 10, padding: '11px 13px', color: '#fff', fontSize: 14, outline: 'none' },
  submitBtn: { background: '#7c6af7', color: '#fff', border: 'none', borderRadius: 10, padding: '13px 28px', fontSize: 15, fontWeight: 700, cursor: 'pointer', alignSelf: 'flex-start' },
  sectionTitle: { color: '#fff', fontSize: 20, fontWeight: 700, marginBottom: 16 },
  appList: { display: 'flex', flexDirection: 'column', gap: 12 },
  appRow: { background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 14, padding: '18px 20px', display: 'flex', alignItems: 'center', gap: 16 },
  appIcon: { width: 52, height: 52, borderRadius: 12, objectFit: 'cover' },
  appInfo: { flex: 1 },
  appName: { color: '#fff', fontWeight: 700, fontSize: 16 },
  appMeta: { color: '#8b8da0', fontSize: 13, marginTop: 3 },
  prediction: { color: '#7c6af7', fontSize: 12, marginTop: 5 },
  appActions: { display: 'flex', gap: 8, alignItems: 'center' },
  publishBtn: { background: '#1a3a2a', color: '#4ade80', border: '1px solid #4ade80', borderRadius: 8, padding: '7px 14px', fontSize: 13, fontWeight: 600, cursor: 'pointer' },
  publishedBadge: { color: '#4ade80', fontSize: 13, fontWeight: 700 },
  editBtn: { background: '#1a1030', color: '#7c6af7', border: '1px solid #7c6af7', borderRadius: 8, padding: '7px 14px', fontSize: 13, fontWeight: 600, cursor: 'pointer' },
  deleteBtn: { background: '#2a1a1a', color: '#ff6b6b', border: '1px solid #ff6b6b', borderRadius: 8, padding: '7px 14px', fontSize: 13, fontWeight: 600, cursor: 'pointer' },
  empty: { color: '#8b8da0', textAlign: 'center', padding: 40, background: '#12121e', borderRadius: 16, border: '1px solid #1e1e2e' },
};

export default DeveloperConsolePage;
