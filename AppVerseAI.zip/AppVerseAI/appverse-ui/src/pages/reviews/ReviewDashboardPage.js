import React, { useState, useEffect } from 'react';
import { reviewAPI } from '../../api';
import { useAuth } from '../../context/AuthContext';

const ReviewDashboardPage = () => {
  const { user } = useAuth();
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const loadReviews = async () => {
    setLoading(true);
    try {
      const res = await reviewAPI.getMyReviews();
      setReviews(res.data.data || []);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadReviews(); }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this review?')) return;
    try {
      await reviewAPI.delete(id);
      setMsg('Review deleted.');
      await loadReviews();
    } catch (e) { setMsg('Failed to delete.'); }
  };

  const sentimentColor = { POSITIVE: '#4ade80', NEUTRAL: '#f5a623', NEGATIVE: '#ff6b6b' };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <h1 style={styles.title}>My Reviews</h1>
        <p style={styles.subtitle}>Reviews submitted by <span style={styles.name}>{user?.username}</span></p>

        {msg && <div style={{ color: '#4ade80', marginBottom: 16, fontSize: 14 }}>{msg}</div>}

        {loading ? (
          <div style={styles.empty}>Loading your reviews...</div>
        ) : reviews.length === 0 ? (
          <div style={styles.empty}>You haven't reviewed any apps yet.</div>
        ) : (
          <div style={styles.list}>
            {reviews.map(r => (
              <div key={r.id} style={styles.card}>
                <div style={styles.cardHeader}>
                  <div>
                    <div style={styles.appName}>{r.appName}</div>
                    <div style={styles.date}>{new Date(r.createdAt).toLocaleDateString()}</div>
                  </div>
                  <div style={styles.right}>
                    <span style={styles.stars}>{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</span>
                    <span style={{ ...styles.badge, background: r.sentiment === 'POSITIVE' ? '#1a3a2a' : r.sentiment === 'NEGATIVE' ? '#3a1a1a' : '#2a2a1a', color: sentimentColor[r.sentiment] || '#f5a623' }}>
                      {r.sentiment}
                    </span>
                  </div>
                </div>
                <p style={styles.content}>{r.content}</p>
                <div style={styles.cardFooter}>
                  <span style={{ color: '#8b8da0', fontSize: 12 }}>Sentiment score: {r.sentimentScore}</span>
                  <button onClick={() => handleDelete(r.id)} style={styles.deleteBtn}>Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  page: { background: '#0a0a0f', minHeight: '100vh', paddingBottom: 60 },
  container: { maxWidth: 800, margin: '0 auto', padding: '40px 24px' },
  title: { color: '#fff', fontSize: 28, fontWeight: 800, margin: '0 0 6px' },
  subtitle: { color: '#8b8da0', fontSize: 14, marginBottom: 32 },
  name: { color: '#7c6af7', fontWeight: 600 },
  empty: { color: '#8b8da0', textAlign: 'center', padding: 48, background: '#12121e', borderRadius: 16, border: '1px solid #1e1e2e' },
  list: { display: 'flex', flexDirection: 'column', gap: 16 },
  card: { background: '#12121e', border: '1px solid #1e1e2e', borderRadius: 16, padding: 24 },
  cardHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 },
  appName: { color: '#fff', fontWeight: 700, fontSize: 16 },
  date: { color: '#8b8da0', fontSize: 12, marginTop: 3 },
  right: { display: 'flex', alignItems: 'center', gap: 10 },
  stars: { color: '#f5a623', fontSize: 16 },
  badge: { fontSize: 11, fontWeight: 700, padding: '3px 9px', borderRadius: 20 },
  content: { color: '#c0c0d0', lineHeight: 1.7, fontSize: 14, margin: '0 0 14px' },
  cardFooter: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  deleteBtn: { background: '#2a1a1a', color: '#ff6b6b', border: '1px solid #ff6b6b', borderRadius: 8, padding: '6px 14px', fontSize: 12, fontWeight: 600, cursor: 'pointer' },
};

export default ReviewDashboardPage;
