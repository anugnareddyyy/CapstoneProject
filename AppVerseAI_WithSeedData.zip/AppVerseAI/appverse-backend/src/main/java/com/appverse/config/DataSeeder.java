package com.appverse.config;

import com.appverse.entity.*;
import com.appverse.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * DataSeeder — runs once on startup if the database is empty.
 * Seeds: users (admin + developers + users), categories, apps, reviews, downloads.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final AppRepository appRepository;
    private final ReviewRepository reviewRepository;
    private final DownloadRepository downloadRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public void run(String... args) {
        if (userRepository.count() > 0) {
            log.info("DataSeeder: database already has data — skipping seed.");
            return;
        }
        log.info("DataSeeder: seeding demo data...");

        // ── 1. USERS ──────────────────────────────────────────────────────────
        User admin = createUser("admin",       "admin@appverse.com",   "admin123",   "AppVerse Admin",      Role.ADMIN);
        User dev1  = createUser("techcorp",    "techcorp@dev.com",     "dev12345",   "TechCorp Studio",     Role.DEVELOPER);
        User dev2  = createUser("pixelforge",  "pixel@dev.com",        "dev12345",   "PixelForge Labs",     Role.DEVELOPER);
        User dev3  = createUser("cloudnine",   "cloud@dev.com",        "dev12345",   "CloudNine Apps",      Role.DEVELOPER);
        User dev4  = createUser("aiworks",     "ai@dev.com",           "dev12345",   "AI Works Inc",        Role.DEVELOPER);
        User user1 = createUser("alice",       "alice@user.com",       "user1234",   "Alice Johnson",       Role.USER);
        User user2 = createUser("bob",         "bob@user.com",         "user1234",   "Bob Williams",        Role.USER);
        User user3 = createUser("charlie",     "charlie@user.com",     "user1234",   "Charlie Brown",       Role.USER);
        User user4 = createUser("diana",       "diana@user.com",       "user1234",   "Diana Prince",        Role.USER);
        User user5 = createUser("evan",        "evan@user.com",        "user1234",   "Evan Peters",         Role.USER);

        userRepository.saveAll(List.of(admin, dev1, dev2, dev3, dev4, user1, user2, user3, user4, user5));
        log.info("DataSeeder: ✓ Users seeded");

        // ── 2. CATEGORIES ─────────────────────────────────────────────────────
        Category productivity = createCategory("Productivity",  "Tools to boost your daily output",             "📊");
        Category games        = createCategory("Games",         "Mobile and desktop gaming experiences",         "🎮");
        Category health       = createCategory("Health & Fitness","Track fitness, sleep, and nutrition",         "💪");
        Category education    = createCategory("Education",     "Learning platforms and study tools",            "📚");
        Category social       = createCategory("Social",        "Connect, chat, and share with others",          "💬");
        Category finance      = createCategory("Finance",       "Budgeting, investing, and payments",            "💰");
        Category entertainment= createCategory("Entertainment", "Streaming, music, and media apps",              "🎬");
        Category utilities    = createCategory("Utilities",     "Device management and system tools",            "🔧");
        Category travel       = createCategory("Travel",        "Maps, bookings, and travel planning",           "✈️");
        Category food         = createCategory("Food & Drink",  "Recipes, delivery, and dining guides",          "🍕");

        categoryRepository.saveAll(List.of(
                productivity, games, health, education, social,
                finance, entertainment, utilities, travel, food));
        log.info("DataSeeder: ✓ Categories seeded");

        // ── 3. APPS ───────────────────────────────────────────────────────────

        // --- Productivity ---
        App taskFlow = createApp("TaskFlow Pro",
                "The ultimate task management app with AI-powered prioritization. Organize projects, set deadlines, collaborate with teams and let the AI suggest what to tackle next based on your work patterns.",
                "https://ui-avatars.com/api/?name=TaskFlow+Pro&background=6366f1&color=fff&size=120",
                "1.4.2", new BigDecimal("0.00"), true, true, dev1, productivity,
                "v1.4.2: Added AI smart scheduling, dark mode support, Google Calendar sync. Performance improved by 40%.",
                4280L, 4.5);

        App notePad = createApp("NoteVault",
                "A beautiful, distraction-free note-taking app with end-to-end encryption. Supports rich text, code blocks, images, and AI-powered summaries of your notes.",
                "https://ui-avatars.com/api/?name=NoteVault&background=0ea5e9&color=fff&size=120",
                "2.1.0", new BigDecimal("4.99"), true, false, dev2, productivity,
                "v2.1.0: AI note summarization, voice-to-text, PDF export, improved search.",
                1850L, 4.3);

        App focusMode = createApp("FocusZone",
                "Pomodoro-based productivity timer with website blocker, ambient sounds, and work session analytics. Includes an AI coach that adapts break intervals to your energy levels.",
                "https://ui-avatars.com/api/?name=FocusZone&background=f59e0b&color=fff&size=120",
                "1.0.5", new BigDecimal("1.99"), true, false, dev3, productivity,
                "v1.0.5: AI energy tracking, Spotify integration, weekly productivity reports.",
                920L, 4.1);

        // --- Games ---
        App galaxyRush = createApp("Galaxy Rush",
                "An action-packed space shooter with stunning 3D graphics, 50+ levels, and online multiplayer. Unlock ships, upgrade weapons, and battle across the galaxy in epic boss fights.",
                "https://ui-avatars.com/api/?name=Galaxy+Rush&background=7c3aed&color=fff&size=120",
                "3.2.1", new BigDecimal("0.00"), true, true, dev1, games,
                "v3.2.1: New Galaxy map, 10 new ships, multiplayer ranking system, bug fixes.",
                15600L, 4.7);

        App puzzleKing = createApp("Puzzle Kingdom",
                "Thousands of handcrafted puzzles — crosswords, sudoku, word searches, and logic grids. Daily challenges with leaderboards, achievements, and an AI hint system.",
                "https://ui-avatars.com/api/?name=Puzzle+Kingdom&background=10b981&color=fff&size=120",
                "1.8.0", new BigDecimal("0.00"), true, false, dev2, games,
                "v1.8.0: 500 new puzzles, AI adaptive difficulty, offline mode.",
                8300L, 4.4);

        App chessAI = createApp("Chess Master AI",
                "Play chess against an advanced AI with 10 difficulty levels. Analyze your games move by move, learn openings from a library of 10,000 grandmaster games.",
                "https://ui-avatars.com/api/?name=Chess+AI&background=1d4ed8&color=fff&size=120",
                "2.0.0", new BigDecimal("2.99"), true, true, dev4, games,
                "v2.0.0: Neural network AI engine, game analysis mode, opening explorer.",
                6100L, 4.8);

        // --- Health & Fitness ---
        App fitTrack = createApp("FitTrack 360",
                "Complete fitness companion — workout plans, nutrition tracking, sleep analysis, and progress charts. AI recommends personalized workout routines based on your fitness goals and history.",
                "https://ui-avatars.com/api/?name=FitTrack&background=ef4444&color=fff&size=120",
                "4.0.1", new BigDecimal("0.00"), true, true, dev3, health,
                "v4.0.1: AI personal trainer, Apple Health sync, meal photo scanner, new cardio workouts.",
                22400L, 4.6);

        App meditation = createApp("ZenMind",
                "Guided meditation and mindfulness app with 200+ sessions. Tracks your stress levels, breathing exercises, and sleep quality. AI personalizes your daily mindfulness journey.",
                "https://ui-avatars.com/api/?name=ZenMind&background=8b5cf6&color=fff&size=120",
                "2.3.0", new BigDecimal("0.00"), true, false, dev2, health,
                "v2.3.0: Stress tracking via camera, 50 new sleep sounds, AI mood journaling.",
                9800L, 4.5);

        App calorieApp = createApp("NutriScan",
                "Scan any food barcode or photo to instantly get calories, macros, and nutritional info. Tracks your daily intake, water consumption, and generates AI-powered meal plans.",
                "https://ui-avatars.com/api/?name=NutriScan&background=f97316&color=fff&size=120",
                "1.5.2", new BigDecimal("3.99"), true, false, dev1, health,
                "v1.5.2: Improved food recognition AI, 2M+ food database, recipe builder.",
                4500L, 4.2);

        // --- Education ---
        App langLearn = createApp("LinguaAI",
                "Learn any of 40 languages through AI-powered conversations, speech recognition, and adaptive lessons. Gamified XP system keeps you motivated. Perfect for beginners and advanced learners.",
                "https://ui-avatars.com/api/?name=LinguaAI&background=0d9488&color=fff&size=120",
                "5.1.0", new BigDecimal("0.00"), true, true, dev4, education,
                "v5.1.0: 5 new languages, AI conversation partner, grammar correction engine.",
                31200L, 4.9);

        App codeLearn = createApp("CodeCraft",
                "Interactive coding tutorials for Python, Java, JavaScript, and more. Real-time code execution in browser, 500+ challenges, project-based learning paths and AI code reviews.",
                "https://ui-avatars.com/api/?name=CodeCraft&background=0f172a&color=fff&size=120",
                "3.0.0", new BigDecimal("9.99"), true, true, dev3, education,
                "v3.0.0: AI code reviewer, TypeScript course, interview prep mode, certificates.",
                12700L, 4.7);

        App mathPro = createApp("MathGenius",
                "Step-by-step math problem solver from arithmetic to calculus. Take a photo of any math problem and get a fully worked solution. Practice mode with adaptive difficulty.",
                "https://ui-avatars.com/api/?name=MathGenius&background=2563eb&color=fff&size=120",
                "2.2.0", new BigDecimal("0.00"), true, false, dev2, education,
                "v2.2.0: Calculus solver, 3D graph plotter, handwriting recognition.",
                7600L, 4.4);

        // --- Social ---
        App friendNet = createApp("FriendLoop",
                "A privacy-first social network where you control your data. Share moments, create groups, host events, and video chat. No ads, no tracking — just real connections.",
                "https://ui-avatars.com/api/?name=FriendLoop&background=ec4899&color=fff&size=120",
                "1.2.0", new BigDecimal("0.00"), true, false, dev1, social,
                "v1.2.0: End-to-end encrypted DMs, stories, group video calls up to 50 people.",
                5400L, 4.0);

        App talkClub = createApp("TalkClub",
                "Voice-based social networking — join live rooms, host discussions, and build a follower community around audio content. Record and share audio clips with AI transcription.",
                "https://ui-avatars.com/api/?name=TalkClub&background=d97706&color=fff&size=120",
                "1.0.2", new BigDecimal("0.00"), true, false, dev4, social,
                "v1.0.2: AI live transcription, room scheduling, guest speaker invites.",
                3200L, 3.9);

        // --- Finance ---
        App budgetWise = createApp("BudgetWise",
                "Smart personal finance manager that links to your bank accounts, categorizes spending automatically, and gives AI-powered savings advice. Visualize net worth and reach financial goals.",
                "https://ui-avatars.com/api/?name=BudgetWise&background=15803d&color=fff&size=120",
                "3.5.0", new BigDecimal("0.00"), true, true, dev3, finance,
                "v3.5.0: Bank sync for 5000+ institutions, AI spending forecasts, tax estimator.",
                11300L, 4.5);

        App cryptoWatch = createApp("CryptoWatch",
                "Real-time cryptocurrency portfolio tracker with price alerts, news feed, and market analysis. AI signals identify buy/sell opportunities based on technical indicators.",
                "https://ui-avatars.com/api/?name=CryptoWatch&background=f59e0b&color=000&size=120",
                "2.8.1", new BigDecimal("0.00"), true, false, dev2, finance,
                "v2.8.1: DeFi portfolio support, AI market signals, 500+ coin tracking.",
                8900L, 4.3);

        // --- Entertainment ---
        App streamPick = createApp("StreamPick AI",
                "Never waste time deciding what to watch. StreamPick AI learns your taste and recommends movies and shows across all your streaming services. One app to rule them all.",
                "https://ui-avatars.com/api/?name=StreamPick&background=dc2626&color=fff&size=120",
                "1.3.0", new BigDecimal("0.00"), true, true, dev4, entertainment,
                "v1.3.0: Supports 12 streaming platforms, watchlist sync, group watch party mode.",
                18200L, 4.6);

        App musicMood = createApp("MoodBeats",
                "AI-curated music playlists based on your current mood, time of day, and activity. Supports Spotify, Apple Music, and YouTube Music. Discover new artists you'll love.",
                "https://ui-avatars.com/api/?name=MoodBeats&background=7c3aed&color=fff&size=120",
                "2.0.0", new BigDecimal("1.99"), true, false, dev1, entertainment,
                "v2.0.0: Mood detection via mic, offline playlists, crossfade support.",
                6700L, 4.4);

        // --- Utilities ---
        App cleanMaster = createApp("CleanVault",
                "Powerful device optimizer — clears junk files, manages storage, and monitors battery health. Safe file vault with biometric lock. Boosts device performance with one tap.",
                "https://ui-avatars.com/api/?name=CleanVault&background=475569&color=fff&size=120",
                "3.1.0", new BigDecimal("0.00"), true, false, dev2, utilities,
                "v3.1.0: Deep clean engine, duplicate file finder, auto-schedule clean.",
                14500L, 4.2);

        App passManager = createApp("KeySafe",
                "Military-grade password manager with zero-knowledge encryption. Auto-fills credentials, generates strong passwords, detects leaked passwords, and secures your digital identity.",
                "https://ui-avatars.com/api/?name=KeySafe&background=1e293b&color=fff&size=120",
                "4.2.0", new BigDecimal("2.99"), true, true, dev3, utilities,
                "v4.2.0: Passkey support, dark web monitoring, secure notes, family sharing.",
                9200L, 4.8);

        // --- Travel ---
        App tripPlanner = createApp("TripMate AI",
                "AI travel planner that builds complete itineraries based on your interests, budget, and travel style. Finds best flights, hotels, and local experiences. Works offline with downloaded maps.",
                "https://ui-avatars.com/api/?name=TripMate&background=0369a1&color=fff&size=120",
                "2.1.0", new BigDecimal("0.00"), true, true, dev4, travel,
                "v2.1.0: AI itinerary builder, flight price predictions, packing list generator.",
                13600L, 4.7);

        App hotelBook = createApp("StayFinder",
                "Compare and book hotels, hostels, and vacation rentals worldwide. Price calendar shows cheapest days to stay. AI predicts whether prices will rise or fall in the next 7 days.",
                "https://ui-avatars.com/api/?name=StayFinder&background=0891b2&color=fff&size=120",
                "1.6.0", new BigDecimal("0.00"), true, false, dev1, travel,
                "v1.6.0: Price prediction AI, loyalty points tracker, instant booking.",
                5800L, 4.1);

        // --- Food ---
        App recipeAI = createApp("ChefBot",
                "AI recipe generator that creates custom recipes from ingredients in your fridge. Step-by-step cooking instructions with videos, nutritional info, and grocery list export.",
                "https://ui-avatars.com/api/?name=ChefBot&background=dc2626&color=fff&size=120",
                "1.9.0", new BigDecimal("0.00"), true, true, dev2, food,
                "v1.9.0: Photo-to-recipe, dietary filter (vegan, keto, gluten-free), meal prepping mode.",
                10200L, 4.6);

        App foodDeliver = createApp("QuickBite",
                "Fast food delivery from restaurants near you with real-time tracking. Group order feature lets friends add items to a shared cart. AI suggests reorders based on your food history.",
                "https://ui-avatars.com/api/?name=QuickBite&background=ea580c&color=fff&size=120",
                "3.4.0", new BigDecimal("0.00"), true, false, dev3, food,
                "v3.4.0: Group ordering, scheduled delivery, AI reorder suggestions, loyalty rewards.",
                7400L, 4.3);

        appRepository.saveAll(List.of(
                taskFlow, notePad, focusMode,
                galaxyRush, puzzleKing, chessAI,
                fitTrack, meditation, calorieApp,
                langLearn, codeLearn, mathPro,
                friendNet, talkClub,
                budgetWise, cryptoWatch,
                streamPick, musicMood,
                cleanMaster, passManager,
                tripPlanner, hotelBook,
                recipeAI, foodDeliver
        ));
        log.info("DataSeeder: ✓ Apps seeded (24 apps)");

        // ── 4. REVIEWS ────────────────────────────────────────────────────────

        // TaskFlow Pro
        saveReview(user1, taskFlow, 5, "TaskFlow Pro completely changed how I manage my projects. The AI prioritization is spot on!", "POSITIVE", 0.9);
        saveReview(user2, taskFlow, 4, "Great task manager, very clean UI. Would love desktop sync but overall excellent.", "POSITIVE", 0.75);
        saveReview(user3, taskFlow, 5, "Best productivity app I have ever used. The team collaboration features are amazing!", "POSITIVE", 0.95);
        saveReview(user4, taskFlow, 3, "Decent app but the free tier is quite limited. Needs more features without subscription.", "NEUTRAL", 0.1);

        // Galaxy Rush
        saveReview(user1, galaxyRush, 5, "Absolutely love Galaxy Rush! The graphics are stunning and the gameplay is super addictive.", "POSITIVE", 0.92);
        saveReview(user2, galaxyRush, 5, "Best space shooter on the market. Multiplayer mode is incredible, plays smoothly every time.", "POSITIVE", 0.88);
        saveReview(user3, galaxyRush, 4, "Amazing game with great visuals. Some boss levels are way too hard but overall fantastic.", "POSITIVE", 0.7);
        saveReview(user5, galaxyRush, 2, "Fun at first but gets repetitive after 20 levels. The ads are annoying and break the flow.", "NEGATIVE", -0.6);

        // FitTrack 360
        saveReview(user2, fitTrack, 5, "FitTrack 360 is phenomenal! Lost 12kg using this app. The AI workout coach is genuinely helpful.", "POSITIVE", 0.95);
        saveReview(user3, fitTrack, 5, "Best fitness app — tracks everything perfectly. Love the sleep analysis feature, very accurate.", "POSITIVE", 0.9);
        saveReview(user4, fitTrack, 4, "Really good overall. Some UI glitches on older phones but the workout plans are excellent.", "POSITIVE", 0.65);
        saveReview(user5, fitTrack, 1, "The app crashed repeatedly during my workout session and lost all my data. Very frustrating!", "NEGATIVE", -0.85);

        // LinguaAI
        saveReview(user1, langLearn, 5, "LinguaAI is hands down the best language learning app. Learned Spanish to conversational level in 3 months!", "POSITIVE", 0.97);
        saveReview(user4, langLearn, 5, "The AI conversation partner is incredibly realistic. Far better than other language apps.", "POSITIVE", 0.93);
        saveReview(user5, langLearn, 4, "Excellent app for learning. The gamification keeps me motivated. Would love more Asian languages.", "POSITIVE", 0.78);

        // Chess Master AI
        saveReview(user2, chessAI, 5, "The AI opponent is outstanding. Really improved my game in just 2 weeks. Game analysis is superb.", "POSITIVE", 0.94);
        saveReview(user3, chessAI, 5, "Incredible chess app. The 10 difficulty levels are perfectly balanced. Best chess app available.", "POSITIVE", 0.96);
        saveReview(user4, chessAI, 4, "Great app for chess practice. The opening explorer alone is worth the price.", "POSITIVE", 0.8);

        // CodeCraft
        saveReview(user1, codeLearn, 5, "CodeCraft is simply brilliant. Learned Python from scratch and got my first dev job using this!", "POSITIVE", 0.98);
        saveReview(user5, codeLearn, 5, "The AI code reviewer catches mistakes I never would have noticed. Amazing learning tool.", "POSITIVE", 0.91);
        saveReview(user2, codeLearn, 4, "Really good content and project-based approach. The JavaScript course could use an update.", "POSITIVE", 0.72);

        // StreamPick AI
        saveReview(user3, streamPick, 5, "StreamPick AI is magic! It always finds something I want to watch. Saved me hours of browsing.", "POSITIVE", 0.93);
        saveReview(user4, streamPick, 4, "Love the concept of unifying all streaming apps. Recommendations are very accurate.", "POSITIVE", 0.76);
        saveReview(user1, streamPick, 2, "Good idea but slow to load and the streaming service integration breaks regularly.", "NEGATIVE", -0.55);

        // BudgetWise
        saveReview(user2, budgetWise, 5, "BudgetWise completely transformed my finances. Saved $3000 in 6 months following its advice!", "POSITIVE", 0.97);
        saveReview(user5, budgetWise, 4, "Excellent budgeting tool. Bank sync works perfectly. AI insights are surprisingly accurate.", "POSITIVE", 0.82);
        saveReview(user3, budgetWise, 3, "Good app overall but I had trouble linking my bank. Support team was helpful though.", "NEUTRAL", 0.05);

        // KeySafe
        saveReview(user1, passManager, 5, "KeySafe is the gold standard for password managers. Zero-knowledge encryption gives me total peace of mind.", "POSITIVE", 0.95);
        saveReview(user4, passManager, 5, "Switched from another manager and never looked back. Dark web monitoring already caught one leak!", "POSITIVE", 0.92);

        // TripMate AI
        saveReview(user2, tripPlanner, 5, "TripMate AI planned my entire Japan trip! The itinerary it built was perfect. 10/10!", "POSITIVE", 0.99);
        saveReview(user3, tripPlanner, 5, "Best travel app ever. Saved hundreds on flights using its price prediction feature.", "POSITIVE", 0.94);
        saveReview(user5, tripPlanner, 4, "Very useful app. The offline maps worked great on my last international trip.", "POSITIVE", 0.77);

        // ChefBot
        saveReview(user1, recipeAI, 5, "ChefBot is amazing! Made a gourmet meal from random fridge leftovers with its recipe suggestions.", "POSITIVE", 0.93);
        saveReview(user4, recipeAI, 5, "The photo-to-recipe feature is mind-blowing. Great meal plans and nutritional info too.", "POSITIVE", 0.91);
        saveReview(user2, recipeAI, 4, "Really useful for meal planning. Recipe database is massive. Grocery list export is super handy.", "POSITIVE", 0.79);

        // NoteVault
        saveReview(user3, notePad, 4, "Clean and beautiful notes app. The AI summaries save me so much time reviewing long notes.", "POSITIVE", 0.8);
        saveReview(user5, notePad, 3, "Good app but the price is a bit high for what it offers. Sync sometimes lags.", "NEUTRAL", 0.0);

        // ZenMind
        saveReview(user1, meditation, 5, "ZenMind changed my relationship with stress. 30 days of meditation and I feel like a different person.", "POSITIVE", 0.96);
        saveReview(user2, meditation, 4, "Beautiful guided meditations. The sleep sounds feature is absolutely amazing.", "POSITIVE", 0.82);

        // Puzzle Kingdom
        saveReview(user3, puzzleKing, 4, "Thousands of puzzles and they never get old. Love the daily challenge leaderboard.", "POSITIVE", 0.78);
        saveReview(user4, puzzleKing, 5, "Perfect puzzle app. The AI adaptive difficulty keeps puzzles challenging at just the right level.", "POSITIVE", 0.88);

        // FriendLoop
        saveReview(user5, friendNet, 4, "Finally a social network that respects privacy! Clean interface and no ads at all.", "POSITIVE", 0.75);
        saveReview(user1, friendNet, 3, "Great privacy features but my friends aren't on it yet. Chicken-and-egg problem.", "NEUTRAL", 0.1);

        // MoodBeats
        saveReview(user2, musicMood, 4, "MoodBeats nails my music taste every time. The AI mood detection is surprisingly accurate.", "POSITIVE", 0.83);
        saveReview(user3, musicMood, 5, "Best music discovery app. Found so many amazing artists I never would have found otherwise.", "POSITIVE", 0.9);

        log.info("DataSeeder: ✓ Reviews seeded");

        // ── 5. DOWNLOADS ──────────────────────────────────────────────────────

        // Simulate realistic download patterns across users
        List<App> popularApps = List.of(
                langLearn, fitTrack, galaxyRush, streamPick, codeLearn,
                taskFlow, chessAI, budgetWise, tripPlanner, recipeAI,
                meditation, passManager, notePad, cryptoWatch, musicMood
        );

        List<User> allUsers = List.of(user1, user2, user3, user4, user5);

        for (User u : allUsers) {
            // Each user downloads ~8 apps
            for (int i = 0; i < popularApps.size(); i++) {
                if ((i + allUsers.indexOf(u)) % 2 == 0) {
                    saveDownload(u, popularApps.get(i));
                }
            }
        }

        // Extra downloads for admin tracking
        saveDownload(admin, taskFlow);
        saveDownload(admin, langLearn);
        saveDownload(admin, fitTrack);

        log.info("DataSeeder: ✓ Downloads seeded");
        log.info("DataSeeder: ✅ All demo data seeded successfully!");
        log.info("DataSeeder: 🔑 Login credentials:");
        log.info("  Admin    → username: admin      | password: admin123");
        log.info("  Dev 1    → username: techcorp   | password: dev12345");
        log.info("  Dev 2    → username: pixelforge | password: dev12345");
        log.info("  Dev 3    → username: cloudnine  | password: dev12345");
        log.info("  Dev 4    → username: aiworks    | password: dev12345");
        log.info("  User 1   → username: alice      | password: user1234");
        log.info("  User 2   → username: bob        | password: user1234");
        log.info("  User 3   → username: charlie    | password: user1234");
    }

    // ── Private helpers ────────────────────────────────────────────────────

    private User createUser(String username, String email, String password, String fullName, Role role) {
        return User.builder()
                .username(username)
                .email(email)
                .password(passwordEncoder.encode(password))
                .fullName(fullName)
                .role(role)
                .active(true)
                .build();
    }

    private Category createCategory(String name, String description, String icon) {
        return Category.builder()
                .name(name)
                .description(description)
                .iconUrl(icon)
                .build();
    }

    private App createApp(String name, String description, String iconUrl,
                          String version, BigDecimal price, boolean published,
                          boolean featured, User developer, Category category,
                          String releaseNotes, Long totalDownloads, double averageRating) {
        return App.builder()
                .name(name)
                .description(description)
                .iconUrl(iconUrl)
                .downloadUrl("https://appverse.ai/download/" + name.toLowerCase().replace(" ", "-"))
                .version(version)
                .price(price)
                .published(published)
                .featured(featured)
                .developer(developer)
                .category(category)
                .releaseNotes(releaseNotes)
                .totalDownloads(totalDownloads)
                .averageRating(averageRating)
                .build();
    }

    private void saveReview(User user, App app, int rating, String content,
                            String sentiment, double sentimentScore) {
        Review review = Review.builder()
                .user(user)
                .app(app)
                .rating(rating)
                .content(content)
                .sentiment(sentiment)
                .sentimentScore(sentimentScore)
                .flagged(false)
                .build();
        reviewRepository.save(review);
    }

    private void saveDownload(User user, App app) {
        if (!downloadRepository.existsByUserIdAndAppId(user.getId(), app.getId())) {
            Download download = Download.builder()
                    .user(user)
                    .app(app)
                    .appVersion(app.getVersion())
                    .build();
            downloadRepository.save(download);
        }
    }
}
