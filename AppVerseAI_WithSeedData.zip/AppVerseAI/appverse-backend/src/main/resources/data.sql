-- ============================================================
-- AppVerse AI — Full Database Seed Script
-- Run this ONLY if you prefer manual SQL over DataSeeder.java
-- BCrypt hash of "admin123"   = $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LjZAzvV9uku
-- BCrypt hash of "dev12345"   = $2a$10$8K1p/a0dL1LXMIgoEDFrwOdDvlWi7q6R8yHH0I.klRWLpQhCGMz0m
-- BCrypt hash of "user1234"   = $2a$10$mI2BIh2xU6G/O5GReFkEKO.KQT/d0DKXV5MV.j2T3f6d.z7VNdXuC
-- ============================================================

USE appverse_db;

-- ── USERS ──────────────────────────────────────────────────────────────────
INSERT INTO users (username, email, password, full_name, role, is_active) VALUES
('admin',      'admin@appverse.com',    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LjZAzvV9uku', 'AppVerse Admin',    'ADMIN',     1),
('techcorp',   'techcorp@dev.com',      '$2a$10$8K1p/a0dL1LXMIgoEDFrwOdDvlWi7q6R8yHH0I.klRWLpQhCGMz0m', 'TechCorp Studio',   'DEVELOPER', 1),
('pixelforge', 'pixel@dev.com',         '$2a$10$8K1p/a0dL1LXMIgoEDFrwOdDvlWi7q6R8yHH0I.klRWLpQhCGMz0m', 'PixelForge Labs',   'DEVELOPER', 1),
('cloudnine',  'cloud@dev.com',         '$2a$10$8K1p/a0dL1LXMIgoEDFrwOdDvlWi7q6R8yHH0I.klRWLpQhCGMz0m', 'CloudNine Apps',    'DEVELOPER', 1),
('aiworks',    'ai@dev.com',            '$2a$10$8K1p/a0dL1LXMIgoEDFrwOdDvlWi7q6R8yHH0I.klRWLpQhCGMz0m', 'AI Works Inc',      'DEVELOPER', 1),
('alice',      'alice@user.com',        '$2a$10$mI2BIh2xU6G/O5GReFkEKO.KQT/d0DKXV5MV.j2T3f6d.z7VNdXuC', 'Alice Johnson',     'USER',      1),
('bob',        'bob@user.com',          '$2a$10$mI2BIh2xU6G/O5GReFkEKO.KQT/d0DKXV5MV.j2T3f6d.z7VNdXuC', 'Bob Williams',      'USER',      1),
('charlie',    'charlie@user.com',      '$2a$10$mI2BIh2xU6G/O5GReFkEKO.KQT/d0DKXV5MV.j2T3f6d.z7VNdXuC', 'Charlie Brown',     'USER',      1),
('diana',      'diana@user.com',        '$2a$10$mI2BIh2xU6G/O5GReFkEKO.KQT/d0DKXV5MV.j2T3f6d.z7VNdXuC', 'Diana Prince',      'USER',      1),
('evan',       'evan@user.com',         '$2a$10$mI2BIh2xU6G/O5GReFkEKO.KQT/d0DKXV5MV.j2T3f6d.z7VNdXuC', 'Evan Peters',       'USER',      1);

-- ── CATEGORIES ─────────────────────────────────────────────────────────────
INSERT INTO categories (name, description, icon_url) VALUES
('Productivity',    'Tools to boost your daily output',              '📊'),
('Games',           'Mobile and desktop gaming experiences',          '🎮'),
('Health & Fitness','Track fitness, sleep, and nutrition',            '💪'),
('Education',       'Learning platforms and study tools',             '📚'),
('Social',          'Connect, chat, and share with others',           '💬'),
('Finance',         'Budgeting, investing, and payments',             '💰'),
('Entertainment',   'Streaming, music, and media apps',               '🎬'),
('Utilities',       'Device management and system tools',             '🔧'),
('Travel',          'Maps, bookings, and travel planning',            '✈️'),
('Food & Drink',    'Recipes, delivery, and dining guides',           '🍕');

-- ── APPS ───────────────────────────────────────────────────────────────────
-- Productivity (category_id=1, developers: techcorp=2, pixelforge=3, cloudnine=4)
INSERT INTO apps (name, description, icon_url, download_url, version, price, average_rating, total_downloads, release_notes, is_published, is_featured, developer_id, category_id) VALUES
('TaskFlow Pro',
 'The ultimate task management app with AI-powered prioritization. Organize projects, set deadlines, collaborate with teams and let the AI suggest what to tackle next based on your work patterns.',
 'https://ui-avatars.com/api/?name=TaskFlow+Pro&background=6366f1&color=fff&size=120',
 'https://appverse.ai/download/taskflow-pro', '1.4.2', 0.00, 4.5, 4280,
 'v1.4.2: Added AI smart scheduling, dark mode, Google Calendar sync. 40% performance improvement.',
 1, 1, 2, 1),

('NoteVault',
 'A beautiful, distraction-free note-taking app with end-to-end encryption. Supports rich text, code blocks, images, and AI-powered summaries of your notes.',
 'https://ui-avatars.com/api/?name=NoteVault&background=0ea5e9&color=fff&size=120',
 'https://appverse.ai/download/notevault', '2.1.0', 4.99, 4.3, 1850,
 'v2.1.0: AI note summarization, voice-to-text, PDF export, improved search.',
 1, 0, 3, 1),

('FocusZone',
 'Pomodoro-based productivity timer with website blocker, ambient sounds, and work session analytics. AI coach adapts break intervals to your energy levels.',
 'https://ui-avatars.com/api/?name=FocusZone&background=f59e0b&color=fff&size=120',
 'https://appverse.ai/download/focuszone', '1.0.5', 1.99, 4.1, 920,
 'v1.0.5: AI energy tracking, Spotify integration, weekly productivity reports.',
 1, 0, 4, 1),

-- Games (category_id=2)
('Galaxy Rush',
 'An action-packed space shooter with stunning 3D graphics, 50+ levels, and online multiplayer. Unlock ships, upgrade weapons, and battle across the galaxy in epic boss fights.',
 'https://ui-avatars.com/api/?name=Galaxy+Rush&background=7c3aed&color=fff&size=120',
 'https://appverse.ai/download/galaxy-rush', '3.2.1', 0.00, 4.7, 15600,
 'v3.2.1: New Galaxy map, 10 new ships, multiplayer ranking system, bug fixes.',
 1, 1, 2, 2),

('Puzzle Kingdom',
 'Thousands of handcrafted puzzles — crosswords, sudoku, word searches, and logic grids. Daily challenges with leaderboards, achievements, and an AI hint system.',
 'https://ui-avatars.com/api/?name=Puzzle+Kingdom&background=10b981&color=fff&size=120',
 'https://appverse.ai/download/puzzle-kingdom', '1.8.0', 0.00, 4.4, 8300,
 'v1.8.0: 500 new puzzles, AI adaptive difficulty, offline mode.',
 1, 0, 3, 2),

('Chess Master AI',
 'Play chess against an advanced AI with 10 difficulty levels. Analyze your games move by move, learn openings from a library of 10,000 grandmaster games.',
 'https://ui-avatars.com/api/?name=Chess+AI&background=1d4ed8&color=fff&size=120',
 'https://appverse.ai/download/chess-master-ai', '2.0.0', 2.99, 4.8, 6100,
 'v2.0.0: Neural network AI engine, game analysis mode, opening explorer.',
 1, 1, 5, 2),

-- Health & Fitness (category_id=3)
('FitTrack 360',
 'Complete fitness companion with workout plans, nutrition tracking, sleep analysis, and progress charts. AI recommends personalized workout routines based on your fitness goals and history.',
 'https://ui-avatars.com/api/?name=FitTrack&background=ef4444&color=fff&size=120',
 'https://appverse.ai/download/fittrack-360', '4.0.1', 0.00, 4.6, 22400,
 'v4.0.1: AI personal trainer, Apple Health sync, meal photo scanner, new cardio workouts.',
 1, 1, 4, 3),

('ZenMind',
 'Guided meditation and mindfulness app with 200+ sessions. Tracks stress levels, breathing exercises, and sleep quality. AI personalizes your daily mindfulness journey.',
 'https://ui-avatars.com/api/?name=ZenMind&background=8b5cf6&color=fff&size=120',
 'https://appverse.ai/download/zenmind', '2.3.0', 0.00, 4.5, 9800,
 'v2.3.0: Stress tracking via camera, 50 new sleep sounds, AI mood journaling.',
 1, 0, 3, 3),

('NutriScan',
 'Scan any food barcode or photo to instantly get calories, macros, and nutritional info. Tracks daily intake, water consumption, and generates AI-powered meal plans.',
 'https://ui-avatars.com/api/?name=NutriScan&background=f97316&color=fff&size=120',
 'https://appverse.ai/download/nutriscan', '1.5.2', 3.99, 4.2, 4500,
 'v1.5.2: Improved food recognition AI, 2M+ food database, recipe builder.',
 1, 0, 2, 3),

-- Education (category_id=4)
('LinguaAI',
 'Learn any of 40 languages through AI-powered conversations, speech recognition, and adaptive lessons. Gamified XP system keeps you motivated. Perfect for beginners and advanced learners.',
 'https://ui-avatars.com/api/?name=LinguaAI&background=0d9488&color=fff&size=120',
 'https://appverse.ai/download/linguaai', '5.1.0', 0.00, 4.9, 31200,
 'v5.1.0: 5 new languages, AI conversation partner, grammar correction engine.',
 1, 1, 5, 4),

('CodeCraft',
 'Interactive coding tutorials for Python, Java, JavaScript, and more. Real-time code execution in browser, 500+ challenges, project-based learning paths and AI code reviews.',
 'https://ui-avatars.com/api/?name=CodeCraft&background=0f172a&color=fff&size=120',
 'https://appverse.ai/download/codecraft', '3.0.0', 9.99, 4.7, 12700,
 'v3.0.0: AI code reviewer, TypeScript course, interview prep mode, certificates.',
 1, 1, 4, 4),

('MathGenius',
 'Step-by-step math problem solver from arithmetic to calculus. Take a photo of any math problem and get a fully worked solution. Practice mode with adaptive difficulty.',
 'https://ui-avatars.com/api/?name=MathGenius&background=2563eb&color=fff&size=120',
 'https://appverse.ai/download/mathgenius', '2.2.0', 0.00, 4.4, 7600,
 'v2.2.0: Calculus solver, 3D graph plotter, handwriting recognition.',
 1, 0, 3, 4),

-- Social (category_id=5)
('FriendLoop',
 'A privacy-first social network where you control your data. Share moments, create groups, host events, and video chat. No ads, no tracking — just real connections.',
 'https://ui-avatars.com/api/?name=FriendLoop&background=ec4899&color=fff&size=120',
 'https://appverse.ai/download/friendloop', '1.2.0', 0.00, 4.0, 5400,
 'v1.2.0: End-to-end encrypted DMs, stories, group video calls up to 50 people.',
 1, 0, 2, 5),

('TalkClub',
 'Voice-based social networking — join live rooms, host discussions, and build a follower community around audio content. Record and share audio clips with AI transcription.',
 'https://ui-avatars.com/api/?name=TalkClub&background=d97706&color=fff&size=120',
 'https://appverse.ai/download/talkclub', '1.0.2', 0.00, 3.9, 3200,
 'v1.0.2: AI live transcription, room scheduling, guest speaker invites.',
 1, 0, 5, 5),

-- Finance (category_id=6)
('BudgetWise',
 'Smart personal finance manager that links to your bank accounts, categorizes spending automatically, and gives AI-powered savings advice. Visualize net worth and reach financial goals.',
 'https://ui-avatars.com/api/?name=BudgetWise&background=15803d&color=fff&size=120',
 'https://appverse.ai/download/budgetwise', '3.5.0', 0.00, 4.5, 11300,
 'v3.5.0: Bank sync for 5000+ institutions, AI spending forecasts, tax estimator.',
 1, 1, 4, 6),

('CryptoWatch',
 'Real-time cryptocurrency portfolio tracker with price alerts, news feed, and market analysis. AI signals identify buy/sell opportunities based on technical indicators.',
 'https://ui-avatars.com/api/?name=CryptoWatch&background=f59e0b&color=000&size=120',
 'https://appverse.ai/download/cryptowatch', '2.8.1', 0.00, 4.3, 8900,
 'v2.8.1: DeFi portfolio support, AI market signals, 500+ coin tracking.',
 1, 0, 3, 6),

-- Entertainment (category_id=7)
('StreamPick AI',
 'Never waste time deciding what to watch. StreamPick AI learns your taste and recommends movies and shows across all your streaming services. One app to rule them all.',
 'https://ui-avatars.com/api/?name=StreamPick&background=dc2626&color=fff&size=120',
 'https://appverse.ai/download/streampick-ai', '1.3.0', 0.00, 4.6, 18200,
 'v1.3.0: Supports 12 streaming platforms, watchlist sync, group watch party mode.',
 1, 1, 5, 7),

('MoodBeats',
 'AI-curated music playlists based on your current mood, time of day, and activity. Supports Spotify, Apple Music, and YouTube Music. Discover new artists you will love.',
 'https://ui-avatars.com/api/?name=MoodBeats&background=7c3aed&color=fff&size=120',
 'https://appverse.ai/download/moodbeats', '2.0.0', 1.99, 4.4, 6700,
 'v2.0.0: Mood detection via mic, offline playlists, crossfade support.',
 1, 0, 2, 7),

-- Utilities (category_id=8)
('CleanVault',
 'Powerful device optimizer — clears junk files, manages storage, and monitors battery health. Safe file vault with biometric lock. Boosts device performance with one tap.',
 'https://ui-avatars.com/api/?name=CleanVault&background=475569&color=fff&size=120',
 'https://appverse.ai/download/cleanvault', '3.1.0', 0.00, 4.2, 14500,
 'v3.1.0: Deep clean engine, duplicate file finder, auto-schedule clean.',
 1, 0, 3, 8),

('KeySafe',
 'Military-grade password manager with zero-knowledge encryption. Auto-fills credentials, generates strong passwords, detects leaked passwords, and secures your digital identity.',
 'https://ui-avatars.com/api/?name=KeySafe&background=1e293b&color=fff&size=120',
 'https://appverse.ai/download/keysafe', '4.2.0', 2.99, 4.8, 9200,
 'v4.2.0: Passkey support, dark web monitoring, secure notes, family sharing.',
 1, 1, 4, 8),

-- Travel (category_id=9)
('TripMate AI',
 'AI travel planner that builds complete itineraries based on your interests, budget, and travel style. Finds best flights, hotels, and local experiences. Works offline with downloaded maps.',
 'https://ui-avatars.com/api/?name=TripMate&background=0369a1&color=fff&size=120',
 'https://appverse.ai/download/tripmate-ai', '2.1.0', 0.00, 4.7, 13600,
 'v2.1.0: AI itinerary builder, flight price predictions, packing list generator.',
 1, 1, 5, 9),

('StayFinder',
 'Compare and book hotels, hostels, and vacation rentals worldwide. Price calendar shows cheapest days to stay. AI predicts whether prices will rise or fall in the next 7 days.',
 'https://ui-avatars.com/api/?name=StayFinder&background=0891b2&color=fff&size=120',
 'https://appverse.ai/download/stayfinder', '1.6.0', 0.00, 4.1, 5800,
 'v1.6.0: Price prediction AI, loyalty points tracker, instant booking.',
 1, 0, 2, 9),

-- Food & Drink (category_id=10)
('ChefBot',
 'AI recipe generator that creates custom recipes from ingredients in your fridge. Step-by-step cooking instructions with videos, nutritional info, and grocery list export.',
 'https://ui-avatars.com/api/?name=ChefBot&background=dc2626&color=fff&size=120',
 'https://appverse.ai/download/chefbot', '1.9.0', 0.00, 4.6, 10200,
 'v1.9.0: Photo-to-recipe, dietary filter (vegan, keto, gluten-free), meal prepping mode.',
 1, 1, 3, 10),

('QuickBite',
 'Fast food delivery from restaurants near you with real-time tracking. Group order feature lets friends add items. AI suggests reorders based on your food history.',
 'https://ui-avatars.com/api/?name=QuickBite&background=ea580c&color=fff&size=120',
 'https://appverse.ai/download/quickbite', '3.4.0', 0.00, 4.3, 7400,
 'v3.4.0: Group ordering, scheduled delivery, AI reorder suggestions, loyalty rewards.',
 1, 0, 4, 10);


-- ── REVIEWS ────────────────────────────────────────────────────────────────
-- app_id 1=TaskFlow, 4=Galaxy Rush, 7=FitTrack, 10=LinguaAI, 6=Chess, 11=CodeCraft
-- users: alice=6,bob=7,charlie=8,diana=9,evan=10

INSERT INTO reviews (content, rating, sentiment, sentiment_score, is_flagged, user_id, app_id) VALUES
-- TaskFlow Pro (app 1)
('TaskFlow Pro completely changed how I manage my projects. The AI prioritization is spot on!',           5,'POSITIVE', 0.90, 0, 6, 1),
('Great task manager, very clean UI. Would love desktop sync but overall excellent app.',                 4,'POSITIVE', 0.75, 0, 7, 1),
('Best productivity app I have ever used. The team collaboration features are amazing!',                  5,'POSITIVE', 0.95, 0, 8, 1),
('Decent app but the free tier is quite limited. Needs more features without a subscription.',            3,'NEUTRAL',  0.10, 0, 9, 1),
-- Galaxy Rush (app 4)
('Absolutely love Galaxy Rush! The graphics are stunning and gameplay is super addictive.',               5,'POSITIVE', 0.92, 0, 6, 4),
('Best space shooter on the market. Multiplayer mode is incredible, plays so smoothly.',                 5,'POSITIVE', 0.88, 0, 7, 4),
('Amazing game with great visuals. Some boss levels are way too hard but overall fantastic.',             4,'POSITIVE', 0.70, 0, 8, 4),
('Fun at first but gets repetitive after 20 levels. Ads are annoying and break the flow.',               2,'NEGATIVE',-0.60, 0,10, 4),
-- FitTrack 360 (app 7)
('FitTrack 360 is phenomenal! Lost 12kg using this. The AI workout coach is genuinely helpful.',         5,'POSITIVE', 0.95, 0, 7, 7),
('Best fitness app — tracks everything perfectly. Love the sleep analysis, very accurate.',               5,'POSITIVE', 0.90, 0, 8, 7),
('Really good overall. Some UI glitches on older phones but workout plans are excellent.',                4,'POSITIVE', 0.65, 0, 9, 7),
('The app crashed repeatedly during my workout and lost all my data. Very frustrating!',                  1,'NEGATIVE',-0.85, 0,10, 7),
-- LinguaAI (app 10)
('Best language learning app. Learned Spanish to conversational level in just 3 months!',                5,'POSITIVE', 0.97, 0, 6,10),
('The AI conversation partner is incredibly realistic. Far better than other language apps.',             5,'POSITIVE', 0.93, 0, 9,10),
('Excellent app for learning. The gamification keeps me motivated. More Asian languages please.',         4,'POSITIVE', 0.78, 0,10,10),
-- Chess Master AI (app 6)
('The AI opponent is outstanding. Really improved my game in just 2 weeks. Analysis is superb.',         5,'POSITIVE', 0.94, 0, 7, 6),
('Incredible chess app. The 10 difficulty levels are perfectly balanced. Best chess app out there.',      5,'POSITIVE', 0.96, 0, 8, 6),
('Great app for chess practice. The opening explorer alone is worth the download.',                      4,'POSITIVE', 0.80, 0, 9, 6),
-- CodeCraft (app 11)
('CodeCraft is brilliant. Learned Python from scratch and got my first developer job using this!',       5,'POSITIVE', 0.98, 0, 6,11),
('The AI code reviewer catches mistakes I never would have noticed. Amazing learning tool.',              5,'POSITIVE', 0.91, 0,10,11),
('Really good content. The JavaScript course could use an update but overall great.',                    4,'POSITIVE', 0.72, 0, 7,11),
-- StreamPick AI (app 17)
('StreamPick AI is magic! Always finds something I want to watch. Saved me hours of browsing.',          5,'POSITIVE', 0.93, 0, 8,17),
('Love the concept of unifying all streaming apps. Recommendations are very accurate.',                  4,'POSITIVE', 0.76, 0, 9,17),
('Good idea but slow to load and the streaming service integration breaks regularly.',                    2,'NEGATIVE',-0.55, 0, 6,17),
-- BudgetWise (app 15)
('BudgetWise transformed my finances. Saved $3000 in 6 months following its advice!',                   5,'POSITIVE', 0.97, 0, 7,15),
('Excellent budgeting tool. Bank sync works perfectly. AI insights are surprisingly accurate.',           4,'POSITIVE', 0.82, 0,10,15),
('Good app overall but I had trouble linking my bank. Support team was helpful though.',                  3,'NEUTRAL',  0.05, 0, 8,15),
-- KeySafe (app 20)
('KeySafe is the gold standard for password managers. Zero-knowledge encryption is perfect.',            5,'POSITIVE', 0.95, 0, 6,20),
('Switched from another manager and never looked back. Dark web monitoring caught one leak!',            5,'POSITIVE', 0.92, 0, 9,20),
-- TripMate AI (app 21)
('TripMate AI planned my entire Japan trip! The itinerary it built was absolutely perfect.',             5,'POSITIVE', 0.99, 0, 7,21),
('Best travel app ever. Saved hundreds on flights using its price prediction feature.',                  5,'POSITIVE', 0.94, 0, 8,21),
('Very useful app. The offline maps worked great on my last international trip.',                        4,'POSITIVE', 0.77, 0,10,21),
-- ChefBot (app 23)
('ChefBot is amazing! Made a gourmet meal from random fridge leftovers. Incredible app!',               5,'POSITIVE', 0.93, 0, 6,23),
('The photo-to-recipe feature is mind-blowing. Great meal plans and nutritional info too.',              5,'POSITIVE', 0.91, 0, 9,23),
('Really useful for meal planning. Recipe database is massive. Grocery list export is handy.',           4,'POSITIVE', 0.79, 0, 7,23),
-- ZenMind (app 8)
('ZenMind changed my relationship with stress. 30 days of meditation and I feel amazing.',              5,'POSITIVE', 0.96, 0, 6, 8),
('Beautiful guided meditations. The sleep sounds feature is absolutely incredible.',                    4,'POSITIVE', 0.82, 0, 7, 8),
-- MoodBeats (app 18)
('MoodBeats nails my music taste every time. The AI mood detection is surprisingly accurate.',          4,'POSITIVE', 0.83, 0, 7,18),
('Best music discovery app. Found amazing artists I never would have found otherwise.',                 5,'POSITIVE', 0.90, 0, 8,18);


-- ── DOWNLOADS ──────────────────────────────────────────────────────────────
INSERT INTO downloads (user_id, app_id, app_version) VALUES
(6,  1, '1.4.2'), (6,  4, '3.2.1'), (6,  7, '4.0.1'), (6, 10, '5.1.0'),
(6, 11, '3.0.0'), (6, 15, '3.5.0'), (6, 17, '1.3.0'), (6, 20, '4.2.0'),
(6, 21, '2.1.0'), (6, 23, '1.9.0'),
(7,  1, '1.4.2'), (7,  4, '3.2.1'), (7,  6, '2.0.0'), (7,  7, '4.0.1'),
(7, 10, '5.1.0'), (7, 11, '3.0.0'), (7, 15, '3.5.0'), (7, 21, '2.1.0'),
(7, 23, '1.9.0'), (7, 18, '2.0.0'),
(8,  4, '3.2.1'), (8,  6, '2.0.0'), (8,  7, '4.0.1'), (8,  8, '2.3.0'),
(8, 10, '5.1.0'), (8, 11, '3.0.0'), (8, 17, '1.3.0'), (8, 19, '3.1.0'),
(8, 21, '2.1.0'), (8, 23, '1.9.0'),
(9,  1, '1.4.2'), (9,  6, '2.0.0'), (9,  7, '4.0.1'), (9, 10, '5.1.0'),
(9, 14, '1.0.2'), (9, 15, '3.5.0'), (9, 20, '4.2.0'), (9, 21, '2.1.0'),
(9, 23, '1.9.0'), (9, 24, '3.4.0'),
(10, 4, '3.2.1'), (10, 7, '4.0.1'), (10,10, '5.1.0'), (10,11, '3.0.0'),
(10,15, '3.5.0'), (10,16, '2.8.1'), (10,17, '1.3.0'), (10,20, '4.2.0'),
(10,21, '2.1.0'), (10,22, '1.6.0'),
-- admin downloads
(1,  1, '1.4.2'), (1, 10, '5.1.0'), (1,  7, '4.0.1');
