package com.appverse.controller;

import com.appverse.dto.request.ReviewRequest;
import com.appverse.dto.response.ReviewResponse;
import com.appverse.repository.UserRepository;
import com.appverse.service.ReviewService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST controller for review CRUD and AI sentiment analysis.
 *
 * Base URL: /api/reviews
 */
@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Reviews", description = "App reviews and AI sentiment analysis")
public class ReviewController {

    private final ReviewService reviewService;
    private final UserRepository userRepository;

    @GetMapping("/app/{appId}")
    @Operation(summary = "Get paginated reviews for an app")
    public ResponseEntity<Page<ReviewResponse>> getAppReviews(
            @PathVariable Long appId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return ResponseEntity.ok(reviewService.getAppReviews(appId, pageable));
    }

    @PostMapping("/app/{appId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Submit a review for an app",
               security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity<ReviewResponse> submitReview(
            @PathVariable Long appId,
            @Valid @RequestBody ReviewRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {

        Long userId = getUserId(userDetails.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(reviewService.submitReview(appId, request, userId));
    }

    @PutMapping("/{reviewId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Update your review",
               security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity<ReviewResponse> updateReview(
            @PathVariable Long reviewId,
            @Valid @RequestBody ReviewRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {

        Long userId = getUserId(userDetails.getUsername());
        return ResponseEntity.ok(reviewService.updateReview(reviewId, request, userId));
    }

    @DeleteMapping("/{reviewId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Delete your review",
               security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity<Void> deleteReview(
            @PathVariable Long reviewId,
            @AuthenticationPrincipal UserDetails userDetails) {

        Long userId = getUserId(userDetails.getUsername());
        reviewService.deleteReview(reviewId, userId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/app/{appId}/sentiment")
    @Operation(summary = "Get AI sentiment analysis for an app's reviews")
    public ResponseEntity<Map<String, Object>> getSentimentAnalysis(@PathVariable Long appId) {
        return ResponseEntity.ok(reviewService.getSentimentAnalysis(appId));
    }

    @GetMapping("/my-reviews")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get all reviews by current user",
               security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity<List<ReviewResponse>> getMyReviews(
            @AuthenticationPrincipal UserDetails userDetails) {

        Long userId = getUserId(userDetails.getUsername());
        return ResponseEntity.ok(reviewService.getUserReviews(userId));
    }

    @GetMapping("/admin/flagged")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Get fake-flagged reviews for moderation (admin only)",
               security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity<List<ReviewResponse>> getFlaggedReviews() {
        return ResponseEntity.ok(reviewService.getFlaggedReviews());
    }

    @PatchMapping("/{reviewId}/visibility")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Toggle review visibility (admin only)",
               security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity<ReviewResponse> toggleVisibility(@PathVariable Long reviewId) {
        return ResponseEntity.ok(reviewService.toggleReviewVisibility(reviewId));
    }

    private Long getUserId(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Authenticated user not found"))
                .getUserId();
    }
}
