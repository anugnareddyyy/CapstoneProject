package com.appverse.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Entity representing a user review for a marketplace app.
 *
 * Relationships:
 * - ManyToOne -> User (author of the review)
 * - ManyToOne -> App (the reviewed application)
 *
 * Business Rules:
 * - A user can only submit one review per app (enforced by unique constraint)
 * - Sentiment is analyzed by AI and stored as POSITIVE, NEGATIVE, or NEUTRAL
 * - Fake review flag is set by AI analysis or admin moderation
 * - Rating must be between 1 and 5
 */
@Entity
@Table(
    name = "reviews",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uk_user_app_review",
            columnNames = {"user_id", "app_id"}
        )
    },
    indexes = {
        @Index(name = "idx_review_app", columnList = "app_id"),
        @Index(name = "idx_review_user", columnList = "user_id"),
        @Index(name = "idx_review_sentiment", columnList = "sentiment")
    }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "review_id")
    private Long reviewId;

    /**
     * Numeric rating from 1 (worst) to 5 (best).
     */
    @NotNull(message = "Rating is required")
    @Min(value = 1, message = "Rating must be at least 1")
    @Max(value = 5, message = "Rating must not exceed 5")
    @Column(name = "rating", nullable = false)
    private Integer rating;

    /**
     * Written review body. Optional but encouraged.
     */
    @Size(max = 2000, message = "Review text must not exceed 2000 characters")
    @Column(name = "review_text", columnDefinition = "TEXT")
    private String reviewText;

    /**
     * Review title / headline (optional short summary).
     */
    @Size(max = 200, message = "Title must not exceed 200 characters")
    @Column(name = "title", length = 200)
    private String title;

    /**
     * AI-analyzed sentiment: POSITIVE, NEGATIVE, NEUTRAL.
     * Set asynchronously after review submission.
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "sentiment", length = 20)
    @Builder.Default
    private SentimentType sentiment = SentimentType.NEUTRAL;

    /**
     * AI-computed sentiment confidence score (0.0 to 1.0).
     */
    @Column(name = "sentiment_score")
    private Double sentimentScore;

    /**
     * Whether AI or admin flagged this as a potentially fake review.
     */
    @Column(name = "is_fake_flagged")
    @Builder.Default
    private Boolean isFakeFlagged = false;

    /**
     * Whether this review is publicly visible on the marketplace.
     */
    @Column(name = "is_visible")
    @Builder.Default
    private Boolean isVisible = true;

    /**
     * Number of users who found this review helpful.
     */
    @Column(name = "helpful_count")
    @Builder.Default
    private Integer helpfulCount = 0;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "app_id", nullable = false)
    private App app;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
