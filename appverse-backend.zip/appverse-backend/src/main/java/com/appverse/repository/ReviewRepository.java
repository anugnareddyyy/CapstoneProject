package com.appverse.repository;

import com.appverse.entity.Review;
import com.appverse.entity.SentimentType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for Review entity with sentiment analytics support.
 */
@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {

    /**
     * Get all visible reviews for a specific app, newest first.
     */
    Page<Review> findByApp_AppIdAndIsVisibleTrue(Long appId, Pageable pageable);

    /**
     * Get all reviews written by a specific user.
     */
    List<Review> findByUser_UserId(Long userId);

    /**
     * Check if a user has already reviewed an app (enforces one-review-per-user).
     */
    boolean existsByUser_UserIdAndApp_AppId(Long userId, Long appId);

    /**
     * Find the specific review a user wrote for an app.
     */
    Optional<Review> findByUser_UserIdAndApp_AppId(Long userId, Long appId);

    /**
     * Aggregate average rating for an app (used to recalculate app rating).
     */
    @Query("SELECT AVG(r.rating) FROM Review r WHERE r.app.appId = :appId AND r.isVisible = true")
    Double calculateAverageRating(@Param("appId") Long appId);

    /**
     * Count reviews by sentiment for an app (sentiment analytics dashboard).
     */
    @Query("SELECT r.sentiment, COUNT(r) FROM Review r WHERE r.app.appId = :appId " +
           "GROUP BY r.sentiment")
    List<Object[]> countBySentimentForApp(@Param("appId") Long appId);

    /**
     * Get all reviews flagged as potentially fake for admin moderation.
     */
    List<Review> findByIsFakeFlaggedTrue();

    /**
     * Count total reviews for an app (including hidden ones).
     */
    long countByApp_AppId(Long appId);

    /**
     * Count visible reviews for an app (used for review count on listing).
     */
    long countByApp_AppIdAndIsVisibleTrue(Long appId);

    /**
     * Retrieve latest reviews across the platform for admin dashboard.
     */
    @Query("SELECT r FROM Review r ORDER BY r.createdAt DESC")
    List<Review> findRecentReviews(Pageable pageable);
}
