package com.appverse.service;

import com.appverse.dto.request.ReviewRequest;
import com.appverse.dto.response.ReviewResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

/**
 * Service interface for review and AI sentiment analysis operations.
 */
public interface ReviewService {

    /** Get paginated reviews for an app. */
    Page<ReviewResponse> getAppReviews(Long appId, Pageable pageable);

    /** Submit a review for an app. Triggers AI sentiment analysis. */
    ReviewResponse submitReview(Long appId, ReviewRequest request, Long userId);

    /** Update an existing review (author only). */
    ReviewResponse updateReview(Long reviewId, ReviewRequest request, Long userId);

    /** Delete a review (author or admin). */
    void deleteReview(Long reviewId, Long userId);

    /** Get all reviews by a user. */
    List<ReviewResponse> getUserReviews(Long userId);

    /** AI sentiment analysis: get sentiment breakdown for an app. */
    Map<String, Object> getSentimentAnalysis(Long appId);

    /** Admin: get all fake-flagged reviews for moderation. */
    List<ReviewResponse> getFlaggedReviews();

    /** Admin: toggle visibility of a review. */
    ReviewResponse toggleReviewVisibility(Long reviewId);
}
