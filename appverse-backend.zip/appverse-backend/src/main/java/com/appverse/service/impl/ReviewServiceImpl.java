package com.appverse.service.impl;

import com.appverse.dto.request.ReviewRequest;
import com.appverse.dto.response.ReviewResponse;
import com.appverse.entity.*;
import com.appverse.exception.DuplicateResourceException;
import com.appverse.exception.ResourceNotFoundException;
import com.appverse.exception.UnauthorizedActionException;
import com.appverse.repository.AppRepository;
import com.appverse.repository.ReviewRepository;
import com.appverse.repository.UserRepository;
import com.appverse.service.ReviewService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Implementation of ReviewService with built-in AI sentiment analysis.
 *
 * Sentiment analysis uses a rule-based engine (keyword matching + rating correlation)
 * as the core AI feature. In production, this can be replaced with an
 * OpenAI/Gemini API call for more accurate NLP-based analysis.
 *
 * Fake review detection heuristics:
 * - Mismatch between rating and sentiment (e.g., 5 stars but very negative text)
 * - Extremely short reviews with extreme ratings
 * - Multiple submissions from same IP (not implemented here, requires request context)
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository reviewRepository;
    private final AppRepository appRepository;
    private final UserRepository userRepository;

    // Positive sentiment keywords for rule-based AI analysis
    private static final List<String> POSITIVE_KEYWORDS = List.of(
        "excellent", "amazing", "great", "love", "best", "perfect", "awesome",
        "fantastic", "wonderful", "recommend", "helpful", "outstanding", "superb",
        "brilliant", "impressive", "top", "quality", "fast", "easy", "smooth"
    );

    // Negative sentiment keywords
    private static final List<String> NEGATIVE_KEYWORDS = List.of(
        "terrible", "awful", "worst", "hate", "bad", "horrible", "useless",
        "waste", "broken", "crash", "bug", "slow", "poor", "disappointing",
        "frustrating", "annoying", "fail", "error", "problem", "uninstall"
    );

    @Override
    @Transactional(readOnly = true)
    public Page<ReviewResponse> getAppReviews(Long appId, Pageable pageable) {
        if (!appRepository.existsById(appId)) {
            throw new ResourceNotFoundException("App", "appId", appId);
        }
        return reviewRepository.findByApp_AppIdAndIsVisibleTrue(appId, pageable)
                .map(this::mapToResponse);
    }

    @Override
    @Transactional
    public ReviewResponse submitReview(Long appId, ReviewRequest request, Long userId) {
        log.info("User {} submitting review for app {}", userId, appId);

        // Validate app exists
        App app = appRepository.findById(appId)
                .orElseThrow(() -> new ResourceNotFoundException("App", "appId", appId));

        // Validate user exists
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "userId", userId));

        // Enforce one review per user per app
        if (reviewRepository.existsByUser_UserIdAndApp_AppId(userId, appId)) {
            throw new DuplicateResourceException(
                "You have already submitted a review for this app");
        }

        // AI: Analyze sentiment from review text and rating
        SentimentAnalysisResult sentimentResult = analyzeSentiment(
            request.getReviewText(), request.getRating()
        );

        // AI: Flag suspicious reviews
        boolean isFake = detectFakeReview(
            request.getReviewText(), request.getRating(), sentimentResult
        );

        Review review = Review.builder()
                .rating(request.getRating())
                .title(request.getTitle())
                .reviewText(request.getReviewText())
                .sentiment(sentimentResult.sentiment())
                .sentimentScore(sentimentResult.score())
                .isFakeFlagged(isFake)
                .isVisible(!isFake) // Auto-hide flagged reviews pending moderation
                .app(app)
                .user(user)
                .build();

        Review savedReview = reviewRepository.save(review);

        // Recalculate and update app's average rating
        recalculateAppRating(appId);

        log.info("Review saved: id={}, sentiment={}, fake={}", 
                 savedReview.getReviewId(), sentimentResult.sentiment(), isFake);

        return mapToResponse(savedReview);
    }

    @Override
    @Transactional
    public ReviewResponse updateReview(Long reviewId, ReviewRequest request, Long userId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new ResourceNotFoundException("Review", "reviewId", reviewId));

        if (!review.getUser().getUserId().equals(userId)) {
            throw new UnauthorizedActionException("You can only edit your own reviews");
        }

        review.setRating(request.getRating());
        review.setTitle(request.getTitle());
        review.setReviewText(request.getReviewText());

        // Re-analyze sentiment on update
        SentimentAnalysisResult result = analyzeSentiment(request.getReviewText(), request.getRating());
        review.setSentiment(result.sentiment());
        review.setSentimentScore(result.score());

        Review updated = reviewRepository.save(review);
        recalculateAppRating(review.getApp().getAppId());

        return mapToResponse(updated);
    }

    @Override
    @Transactional
    public void deleteReview(Long reviewId, Long userId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new ResourceNotFoundException("Review", "reviewId", reviewId));

        if (!review.getUser().getUserId().equals(userId)) {
            throw new UnauthorizedActionException("You can only delete your own reviews");
        }

        Long appId = review.getApp().getAppId();
        reviewRepository.delete(review);
        recalculateAppRating(appId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReviewResponse> getUserReviews(Long userId) {
        return reviewRepository.findByUser_UserId(userId)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> getSentimentAnalysis(Long appId) {
        if (!appRepository.existsById(appId)) {
            throw new ResourceNotFoundException("App", "appId", appId);
        }

        List<Object[]> sentimentCounts = reviewRepository.countBySentimentForApp(appId);

        Map<String, Long> distribution = new HashMap<>();
        long total = 0;

        for (Object[] row : sentimentCounts) {
            String sentiment = row[0].toString();
            long count = (Long) row[1];
            distribution.put(sentiment, count);
            total += count;
        }

        // Calculate percentages
        Map<String, Double> percentages = new HashMap<>();
        for (Map.Entry<String, Long> entry : distribution.entrySet()) {
            percentages.put(entry.getKey(), total > 0
                ? Math.round((entry.getValue() * 100.0 / total) * 10.0) / 10.0
                : 0.0);
        }

        Double avgRating = reviewRepository.calculateAverageRating(appId);

        Map<String, Object> analysis = new HashMap<>();
        analysis.put("appId", appId);
        analysis.put("totalReviews", total);
        analysis.put("sentimentDistribution", distribution);
        analysis.put("sentimentPercentages", percentages);
        analysis.put("averageRating", avgRating != null
            ? BigDecimal.valueOf(avgRating).setScale(2, RoundingMode.HALF_UP) : 0);
        analysis.put("overallSentiment", deriveOverallSentiment(distribution, total));

        return analysis;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReviewResponse> getFlaggedReviews() {
        return reviewRepository.findByIsFakeFlaggedTrue()
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public ReviewResponse toggleReviewVisibility(Long reviewId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new ResourceNotFoundException("Review", "reviewId", reviewId));

        review.setIsVisible(!review.getIsVisible());
        return mapToResponse(reviewRepository.save(review));
    }

    // ===== AI: SENTIMENT ANALYSIS ENGINE =====

    /**
     * Rule-based sentiment analysis combining keyword matching and rating signal.
     *
     * Algorithm:
     * 1. Count positive and negative keyword matches in review text
     * 2. Use rating as a strong signal (1-2 = negative, 3 = neutral, 4-5 = positive)
     * 3. Combine keyword score and rating signal with weighted average
     * 4. Classify as POSITIVE, NEGATIVE, or NEUTRAL based on final score
     *
     * @param text   review text content
     * @param rating numeric rating 1-5
     * @return SentimentAnalysisResult with classified sentiment and confidence score
     */
    private SentimentAnalysisResult analyzeSentiment(String text, int rating) {
        double keywordScore = 0.5; // Default neutral

        if (text != null && !text.isBlank()) {
            String lowerText = text.toLowerCase();

            long positiveMatches = POSITIVE_KEYWORDS.stream()
                    .filter(lowerText::contains).count();
            long negativeMatches = NEGATIVE_KEYWORDS.stream()
                    .filter(lowerText::contains).count();

            long totalMatches = positiveMatches + negativeMatches;

            if (totalMatches > 0) {
                keywordScore = (double) positiveMatches / totalMatches;
            }
        }

        // Normalize rating to 0-1 range (rating signal)
        double ratingScore = (rating - 1.0) / 4.0;

        // Weighted combination: 60% rating signal, 40% keyword analysis
        double combinedScore = (ratingScore * 0.6) + (keywordScore * 0.4);

        SentimentType sentiment;
        if (combinedScore >= 0.65) {
            sentiment = SentimentType.POSITIVE;
        } else if (combinedScore <= 0.35) {
            sentiment = SentimentType.NEGATIVE;
        } else {
            sentiment = SentimentType.NEUTRAL;
        }

        return new SentimentAnalysisResult(sentiment, Math.round(combinedScore * 100.0) / 100.0);
    }

    /**
     * Fake review detection using heuristic rules.
     *
     * Flags as suspicious if:
     * - Rating is extreme (1 or 5) but text sentiment strongly contradicts
     * - Review text is suspiciously short (< 5 words) with extreme rating
     *
     * @param text             review text
     * @param rating           numeric rating
     * @param sentimentResult  result of sentiment analysis
     * @return true if review appears suspicious
     */
    private boolean detectFakeReview(String text, int rating, SentimentAnalysisResult sentimentResult) {
        // Short review with extreme rating — possible fake
        if (text == null || text.trim().split("\\s+").length < 5) {
            if (rating == 1 || rating == 5) {
                return true;
            }
        }

        // Contradictory rating vs sentiment — possible fake
        boolean highRatingNegativeSentiment =
            rating >= 4 && sentimentResult.sentiment() == SentimentType.NEGATIVE;
        boolean lowRatingPositiveSentiment =
            rating <= 2 && sentimentResult.sentiment() == SentimentType.POSITIVE;

        return highRatingNegativeSentiment || lowRatingPositiveSentiment;
    }

    /**
     * Derive overall platform sentiment from distribution counts.
     */
    private String deriveOverallSentiment(Map<String, Long> distribution, long total) {
        if (total == 0) return "NEUTRAL";
        long positive = distribution.getOrDefault("POSITIVE", 0L);
        long negative = distribution.getOrDefault("NEGATIVE", 0L);
        if (positive > negative && positive > total * 0.5) return "POSITIVE";
        if (negative > positive && negative > total * 0.4) return "NEGATIVE";
        return "MIXED";
    }

    /**
     * Recalculate and persist the average rating for an app after a review change.
     * Uses a database aggregate (AVG) for accuracy.
     */
    private void recalculateAppRating(Long appId) {
        App app = appRepository.findById(appId).orElse(null);
        if (app == null) return;

        Double avg = reviewRepository.calculateAverageRating(appId);
        long count = reviewRepository.countByApp_AppIdAndIsVisibleTrue(appId);

        app.setAverageRating(avg != null
            ? BigDecimal.valueOf(avg).setScale(2, RoundingMode.HALF_UP)
            : BigDecimal.ZERO);
        app.setReviewCount((int) count);
        appRepository.save(app);
    }

    /**
     * Maps Review entity to ReviewResponse DTO.
     */
    private ReviewResponse mapToResponse(Review review) {
        return ReviewResponse.builder()
                .reviewId(review.getReviewId())
                .rating(review.getRating())
                .title(review.getTitle())
                .reviewText(review.getReviewText())
                .sentiment(review.getSentiment())
                .sentimentScore(review.getSentimentScore())
                .isFakeFlagged(review.getIsFakeFlagged())
                .helpfulCount(review.getHelpfulCount())
                .userId(review.getUser().getUserId())
                .username(review.getUser().getUsername())
                .avatarUrl(review.getUser().getAvatarUrl())
                .appId(review.getApp().getAppId())
                .appName(review.getApp().getName())
                .createdAt(review.getCreatedAt())
                .build();
    }

    /**
     * Internal record holding the result of sentiment analysis.
     *
     * @param sentiment classified sentiment type
     * @param score     confidence score (0.0 to 1.0)
     */
    private record SentimentAnalysisResult(SentimentType sentiment, double score) {}
}
